﻿namespace LibrarySystem
{
    partial class Dashboard
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            buttonRefresh = new Button();
            panel4 = new Panel();
            label5 = new Label();
            pictureBox3 = new PictureBox();
            label6 = new Label();
            panel3 = new Panel();
            Vydannye_Books = new Label();
            pictureBox2 = new PictureBox();
            label4 = new Label();
            panel2 = new Panel();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            pictureBox4 = new PictureBox();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(buttonRefresh);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(12, 14);
            panel1.Name = "panel1";
            panel1.Size = new Size(855, 237);
            panel1.TabIndex = 0;
            // 
            // buttonRefresh
            // 
            buttonRefresh.BackColor = Color.SeaGreen;
            buttonRefresh.Cursor = Cursors.Hand;
            buttonRefresh.FlatStyle = FlatStyle.Flat;
            buttonRefresh.ForeColor = Color.White;
            buttonRefresh.Location = new Point(12, 193);
            buttonRefresh.Name = "buttonRefresh";
            buttonRefresh.Size = new Size(828, 39);
            buttonRefresh.TabIndex = 18;
            buttonRefresh.Text = "ОБНОВИТЬ";
            buttonRefresh.UseVisualStyleBackColor = false;
            buttonRefresh.Click += buttonRefresh_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.SeaGreen;
            panel4.Controls.Add(label5);
            panel4.Controls.Add(pictureBox3);
            panel4.Controls.Add(label6);
            panel4.Location = new Point(591, 11);
            panel4.Name = "panel4";
            panel4.Size = new Size(249, 168);
            panel4.TabIndex = 3;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.ForeColor = Color.White;
            label5.Location = new Point(202, 117);
            label5.Name = "label5";
            label5.Size = new Size(33, 38);
            label5.TabIndex = 2;
            label5.Text = "0";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.book_37251;
            pictureBox3.Location = new Point(12, 45);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(100, 100);
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.ForeColor = Color.White;
            label6.Location = new Point(91, 19);
            label6.Name = "label6";
            label6.Size = new Size(141, 46);
            label6.TabIndex = 0;
            label6.Text = "Возвращенные \r\n                книги";
            // 
            // panel3
            // 
            panel3.BackColor = Color.SeaGreen;
            panel3.Controls.Add(Vydannye_Books);
            panel3.Controls.Add(pictureBox2);
            panel3.Controls.Add(label4);
            panel3.Location = new Point(305, 11);
            panel3.Name = "panel3";
            panel3.Size = new Size(249, 168);
            panel3.TabIndex = 3;
            // 
            // Vydannye_Books
            // 
            Vydannye_Books.AutoSize = true;
            Vydannye_Books.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            Vydannye_Books.ForeColor = Color.White;
            Vydannye_Books.Location = new Point(202, 117);
            Vydannye_Books.Name = "Vydannye_Books";
            Vydannye_Books.Size = new Size(33, 38);
            Vydannye_Books.TabIndex = 2;
            Vydannye_Books.Text = "0";
            Vydannye_Books.Click += Vydannye_Books_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.book_37251;
            pictureBox2.Location = new Point(3, 45);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(100, 100);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.ForeColor = Color.White;
            label4.Location = new Point(91, 19);
            label4.Name = "label4";
            label4.Size = new Size(152, 23);
            label4.TabIndex = 0;
            label4.Text = "Выданные книги";
            // 
            // panel2
            // 
            panel2.BackColor = Color.SeaGreen;
            panel2.Controls.Add(label2);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(12, 11);
            panel2.Name = "panel2";
            panel2.Size = new Size(249, 168);
            panel2.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.White;
            label2.Location = new Point(201, 117);
            label2.Name = "label2";
            label2.Size = new Size(33, 38);
            label2.TabIndex = 2;
            label2.Text = "0";
            label2.Click += label2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.book_37251;
            pictureBox1.Location = new Point(12, 45);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ForeColor = Color.White;
            label1.Location = new Point(142, 19);
            label1.Name = "label1";
            label1.Size = new Size(92, 23);
            label1.TabIndex = 0;
            label1.Text = "Все книги";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.result_739e6060dcb245018ce790e2074f8556_1378109400;
            pictureBox4.Location = new Point(12, 257);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(855, 295);
            pictureBox4.TabIndex = 1;
            pictureBox4.TabStop = false;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(pictureBox4);
            Controls.Add(panel1);
            Name = "Dashboard";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private Panel panel4;
        private Label label5;
        private PictureBox pictureBox3;
        private Label label6;
        private Panel panel3;
        private Label Vydannye_Books;
        private PictureBox pictureBox2;
        private Label label4;
        private Label label2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private Button buttonRefresh;
    }
}
