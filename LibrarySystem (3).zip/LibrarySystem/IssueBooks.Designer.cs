﻿namespace LibrarySystem
{
    partial class IssueBooks
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Clear = new Button();
            label13 = new Label();
            Readers_IssueBooks = new DataGridView();
            Data_Vydachi_Readers = new DateTimePicker();
            label11 = new Label();
            Author_Readers = new TextBox();
            Name_Book_Readers = new TextBox();
            Email_Readers = new TextBox();
            label10 = new Label();
            label2 = new Label();
            label9 = new Label();
            Number_Phone_Readers = new TextBox();
            label8 = new Label();
            Number_pasport_Readers = new TextBox();
            Seria_Readers = new TextBox();
            Otchestvo_Readers = new TextBox();
            Name_Readers = new TextBox();
            label4 = new Label();
            Familia_Readers = new TextBox();
            label3 = new Label();
            label7 = new Label();
            label5 = new Label();
            label6 = new Label();
            button2 = new Button();
            label1 = new Label();
            All_Issue_Books = new DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Readers_IssueBooks).BeginInit();
            ((System.ComponentModel.ISupportInitialize)All_Issue_Books).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(Clear);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(Readers_IssueBooks);
            panel1.Controls.Add(Data_Vydachi_Readers);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(Author_Readers);
            panel1.Controls.Add(Name_Book_Readers);
            panel1.Controls.Add(Email_Readers);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(Number_Phone_Readers);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(Number_pasport_Readers);
            panel1.Controls.Add(Seria_Readers);
            panel1.Controls.Add(Otchestvo_Readers);
            panel1.Controls.Add(Name_Readers);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(Familia_Readers);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(All_Issue_Books);
            panel1.Location = new Point(15, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(850, 559);
            panel1.TabIndex = 0;
            // 
            // Clear
            // 
            Clear.BackColor = Color.SeaGreen;
            Clear.FlatStyle = FlatStyle.Flat;
            Clear.ForeColor = Color.White;
            Clear.Location = new Point(606, 527);
            Clear.Name = "Clear";
            Clear.Size = new Size(108, 29);
            Clear.TabIndex = 78;
            Clear.Text = "ОЧИСТИТЬ";
            Clear.UseVisualStyleBackColor = false;
            Clear.Click += Clear_Click_1;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label13.Location = new Point(15, 189);
            label13.Name = "label13";
            label13.Size = new Size(309, 20);
            label13.TabIndex = 77;
            label13.Text = "Читатели, которым можно выдать книги";
            // 
            // Readers_IssueBooks
            // 
            Readers_IssueBooks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Readers_IssueBooks.Location = new Point(15, 212);
            Readers_IssueBooks.Name = "Readers_IssueBooks";
            Readers_IssueBooks.RowHeadersWidth = 51;
            Readers_IssueBooks.Size = new Size(821, 134);
            Readers_IssueBooks.TabIndex = 76;
            // 
            // Data_Vydachi_Readers
            // 
            Data_Vydachi_Readers.Location = new Point(712, 361);
            Data_Vydachi_Readers.Name = "Data_Vydachi_Readers";
            Data_Vydachi_Readers.Size = new Size(105, 27);
            Data_Vydachi_Readers.TabIndex = 74;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(606, 361);
            label11.Name = "label11";
            label11.Size = new Size(100, 20);
            label11.TabIndex = 72;
            label11.Text = "Дата выдачи:";
            // 
            // Author_Readers
            // 
            Author_Readers.Location = new Point(446, 475);
            Author_Readers.Name = "Author_Readers";
            Author_Readers.Size = new Size(105, 27);
            Author_Readers.TabIndex = 71;
            // 
            // Name_Book_Readers
            // 
            Name_Book_Readers.Location = new Point(446, 438);
            Name_Book_Readers.Name = "Name_Book_Readers";
            Name_Book_Readers.Size = new Size(105, 27);
            Name_Book_Readers.TabIndex = 70;
            // 
            // Email_Readers
            // 
            Email_Readers.Location = new Point(446, 398);
            Email_Readers.Name = "Email_Readers";
            Email_Readers.Size = new Size(105, 27);
            Email_Readers.TabIndex = 69;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(386, 478);
            label10.Name = "label10";
            label10.Size = new Size(54, 20);
            label10.TabIndex = 68;
            label10.Text = "Автор:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(316, 438);
            label2.Name = "label2";
            label2.Size = new Size(124, 20);
            label2.TabIndex = 67;
            label2.Text = "Название книги:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(294, 398);
            label9.Name = "label9";
            label9.Size = new Size(146, 20);
            label9.TabIndex = 66;
            label9.Text = "Электронная почта:";
            // 
            // Number_Phone_Readers
            // 
            Number_Phone_Readers.Location = new Point(446, 355);
            Number_Phone_Readers.Name = "Number_Phone_Readers";
            Number_Phone_Readers.Size = new Size(105, 27);
            Number_Phone_Readers.TabIndex = 65;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(310, 358);
            label8.Name = "label8";
            label8.Size = new Size(130, 20);
            label8.TabIndex = 64;
            label8.Text = "Номер телефона:";
            // 
            // Number_pasport_Readers
            // 
            Number_pasport_Readers.Location = new Point(162, 515);
            Number_pasport_Readers.Name = "Number_pasport_Readers";
            Number_pasport_Readers.Size = new Size(105, 27);
            Number_pasport_Readers.TabIndex = 63;
            // 
            // Seria_Readers
            // 
            Seria_Readers.Location = new Point(162, 472);
            Seria_Readers.Name = "Seria_Readers";
            Seria_Readers.Size = new Size(105, 27);
            Seria_Readers.TabIndex = 62;
            // 
            // Otchestvo_Readers
            // 
            Otchestvo_Readers.Location = new Point(162, 435);
            Otchestvo_Readers.Name = "Otchestvo_Readers";
            Otchestvo_Readers.Size = new Size(105, 27);
            Otchestvo_Readers.TabIndex = 61;
            // 
            // Name_Readers
            // 
            Name_Readers.Location = new Point(162, 395);
            Name_Readers.Name = "Name_Readers";
            Name_Readers.Size = new Size(105, 27);
            Name_Readers.TabIndex = 60;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(20, 361);
            label4.Name = "label4";
            label4.Size = new Size(141, 20);
            label4.TabIndex = 55;
            label4.Text = "Фамилия читателя:";
            // 
            // Familia_Readers
            // 
            Familia_Readers.Location = new Point(162, 358);
            Familia_Readers.Name = "Familia_Readers";
            Familia_Readers.Size = new Size(105, 27);
            Familia_Readers.TabIndex = 59;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(54, 398);
            label3.Name = "label3";
            label3.Size = new Size(107, 20);
            label3.TabIndex = 54;
            label3.Text = "Имя читателя:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(31, 518);
            label7.Name = "label7";
            label7.Size = new Size(129, 20);
            label7.TabIndex = 58;
            label7.Text = "Номер паспорта:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(20, 438);
            label5.Name = "label5";
            label5.Size = new Size(140, 20);
            label5.TabIndex = 56;
            label5.Text = "Отчество читателя:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(36, 475);
            label6.Name = "label6";
            label6.Size = new Size(124, 20);
            label6.TabIndex = 57;
            label6.Text = "Серия паспорта:";
            // 
            // button2
            // 
            button2.BackColor = Color.SeaGreen;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.White;
            button2.Location = new Point(726, 527);
            button2.Name = "button2";
            button2.Size = new Size(108, 29);
            button2.TabIndex = 24;
            button2.Text = "ВЫДАТЬ";
            button2.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(13, 11);
            label1.Name = "label1";
            label1.Size = new Size(159, 20);
            label1.TabIndex = 1;
            label1.Text = "Все выданные книги";
            // 
            // All_Issue_Books
            // 
            All_Issue_Books.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            All_Issue_Books.Location = new Point(13, 43);
            All_Issue_Books.Name = "All_Issue_Books";
            All_Issue_Books.RowHeadersWidth = 51;
            All_Issue_Books.Size = new Size(821, 134);
            All_Issue_Books.TabIndex = 0;
            // 
            // IssueBooks
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel1);
            Name = "IssueBooks";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Readers_IssueBooks).EndInit();
            ((System.ComponentModel.ISupportInitialize)All_Issue_Books).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private DataGridView All_Issue_Books;
        private Button button2;
        private TextBox Number_Phone_Readers;
        private Label label8;
        private TextBox Number_pasport_Readers;
        private TextBox Seria_Readers;
        private TextBox Otchestvo_Readers;
        private TextBox Name_Readers;
        private Label label4;
        private TextBox Familia_Readers;
        private Label label3;
        private Label label7;
        private Label label5;
        private Label label6;
        private DateTimePicker Data_Vydachi_Readers;
        private Label label11;
        private TextBox Author_Readers;
        private TextBox Name_Book_Readers;
        private TextBox Email_Readers;
        private Label label10;
        private Label label2;
        private Label label9;
        private Label label13;
        private DataGridView Readers_IssueBooks;
        private Button Clear;
    }
}
