﻿namespace LibrarySystem
{
    partial class ReturnBooks
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Date_vozvrata_ = new DateTimePicker();
            Data_Vydachi_Readers = new DateTimePicker();
            label12 = new Label();
            label11 = new Label();
            Author_Readers = new TextBox();
            Name_Book_Readers = new TextBox();
            Email_Readers = new TextBox();
            Number_Phone_Readers = new TextBox();
            label10 = new Label();
            label2 = new Label();
            label9 = new Label();
            label8 = new Label();
            Number_pasport_Readers = new TextBox();
            button2 = new Button();
            Seria_Readers = new TextBox();
            button1 = new Button();
            Otchestvo_Readers = new TextBox();
            Name_Readers = new TextBox();
            label4 = new Label();
            Familia_Readers = new TextBox();
            label3 = new Label();
            label7 = new Label();
            label5 = new Label();
            label6 = new Label();
            panel2 = new Panel();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(Date_vozvrata_);
            panel1.Controls.Add(Data_Vydachi_Readers);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(Author_Readers);
            panel1.Controls.Add(Name_Book_Readers);
            panel1.Controls.Add(Email_Readers);
            panel1.Controls.Add(Number_Phone_Readers);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(Number_pasport_Readers);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(Seria_Readers);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(Otchestvo_Readers);
            panel1.Controls.Add(Name_Readers);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(Familia_Readers);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label6);
            panel1.Location = new Point(15, 17);
            panel1.Name = "panel1";
            panel1.Size = new Size(278, 545);
            panel1.TabIndex = 0;
            // 
            // Date_vozvrata_
            // 
            Date_vozvrata_.Location = new Point(154, 415);
            Date_vozvrata_.Name = "Date_vozvrata_";
            Date_vozvrata_.Size = new Size(105, 27);
            Date_vozvrata_.TabIndex = 60;
            // 
            // Data_Vydachi_Readers
            // 
            Data_Vydachi_Readers.Location = new Point(154, 380);
            Data_Vydachi_Readers.Name = "Data_Vydachi_Readers";
            Data_Vydachi_Readers.Size = new Size(105, 27);
            Data_Vydachi_Readers.TabIndex = 59;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(37, 417);
            label12.Name = "label12";
            label12.Size = new Size(111, 20);
            label12.TabIndex = 58;
            label12.Text = "Дата возврата:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(48, 380);
            label11.Name = "label11";
            label11.Size = new Size(100, 20);
            label11.TabIndex = 57;
            label11.Text = "Дата выдачи:";
            // 
            // Author_Readers
            // 
            Author_Readers.Location = new Point(154, 347);
            Author_Readers.Name = "Author_Readers";
            Author_Readers.Size = new Size(105, 27);
            Author_Readers.TabIndex = 56;
            // 
            // Name_Book_Readers
            // 
            Name_Book_Readers.Location = new Point(154, 310);
            Name_Book_Readers.Name = "Name_Book_Readers";
            Name_Book_Readers.Size = new Size(105, 27);
            Name_Book_Readers.TabIndex = 55;
            // 
            // Email_Readers
            // 
            Email_Readers.Location = new Point(154, 270);
            Email_Readers.Name = "Email_Readers";
            Email_Readers.Size = new Size(105, 27);
            Email_Readers.TabIndex = 54;
            // 
            // Number_Phone_Readers
            // 
            Number_Phone_Readers.Location = new Point(154, 230);
            Number_Phone_Readers.Name = "Number_Phone_Readers";
            Number_Phone_Readers.Size = new Size(105, 27);
            Number_Phone_Readers.TabIndex = 53;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(94, 350);
            label10.Name = "label10";
            label10.Size = new Size(54, 20);
            label10.TabIndex = 52;
            label10.Text = "Автор:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 310);
            label2.Name = "label2";
            label2.Size = new Size(124, 20);
            label2.TabIndex = 51;
            label2.Text = "Название книги:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(2, 270);
            label9.Name = "label9";
            label9.Size = new Size(146, 20);
            label9.TabIndex = 50;
            label9.Text = "Электронная почта:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(18, 233);
            label8.Name = "label8";
            label8.Size = new Size(130, 20);
            label8.TabIndex = 49;
            label8.Text = "Номер телефона:";
            // 
            // Number_pasport_Readers
            // 
            Number_pasport_Readers.Location = new Point(154, 197);
            Number_pasport_Readers.Name = "Number_pasport_Readers";
            Number_pasport_Readers.Size = new Size(105, 27);
            Number_pasport_Readers.TabIndex = 48;
            // 
            // button2
            // 
            button2.BackColor = Color.SeaGreen;
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.White;
            button2.Location = new Point(154, 487);
            button2.Name = "button2";
            button2.Size = new Size(112, 39);
            button2.TabIndex = 17;
            button2.Text = "Очистить";
            button2.UseVisualStyleBackColor = false;
            // 
            // Seria_Readers
            // 
            Seria_Readers.Location = new Point(154, 154);
            Seria_Readers.Name = "Seria_Readers";
            Seria_Readers.Size = new Size(105, 27);
            Seria_Readers.TabIndex = 47;
            // 
            // button1
            // 
            button1.BackColor = Color.SeaGreen;
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.White;
            button1.Location = new Point(19, 487);
            button1.Name = "button1";
            button1.Size = new Size(114, 39);
            button1.TabIndex = 16;
            button1.Text = "Вернуть";
            button1.UseVisualStyleBackColor = false;
            // 
            // Otchestvo_Readers
            // 
            Otchestvo_Readers.Location = new Point(154, 114);
            Otchestvo_Readers.Name = "Otchestvo_Readers";
            Otchestvo_Readers.Size = new Size(105, 27);
            Otchestvo_Readers.TabIndex = 46;
            // 
            // Name_Readers
            // 
            Name_Readers.Location = new Point(154, 74);
            Name_Readers.Name = "Name_Readers";
            Name_Readers.Size = new Size(105, 27);
            Name_Readers.TabIndex = 45;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 40);
            label4.Name = "label4";
            label4.Size = new Size(141, 20);
            label4.TabIndex = 40;
            label4.Text = "Фамилия читателя:";
            // 
            // Familia_Readers
            // 
            Familia_Readers.Location = new Point(154, 37);
            Familia_Readers.Name = "Familia_Readers";
            Familia_Readers.Size = new Size(105, 27);
            Familia_Readers.TabIndex = 44;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 77);
            label3.Name = "label3";
            label3.Size = new Size(107, 20);
            label3.TabIndex = 39;
            label3.Text = "Имя читателя:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(23, 200);
            label7.Name = "label7";
            label7.Size = new Size(129, 20);
            label7.TabIndex = 43;
            label7.Text = "Номер паспорта:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 117);
            label5.Name = "label5";
            label5.Size = new Size(140, 20);
            label5.TabIndex = 41;
            label5.Text = "Отчество читателя:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(28, 157);
            label6.Name = "label6";
            label6.Size = new Size(124, 20);
            label6.TabIndex = 42;
            label6.Text = "Серия паспорта:";
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(314, 17);
            panel2.Name = "panel2";
            panel2.Size = new Size(547, 545);
            panel2.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 57);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(513, 447);
            dataGridView1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(13, 12);
            label1.Name = "label1";
            label1.Size = new Size(238, 31);
            label1.TabIndex = 0;
            label1.Text = "Возвращенные книги";
            // 
            // ReturnBooks
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "ReturnBooks";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private DataGridView dataGridView1;
        private Button button2;
        private Button button1;
        private TextBox Number_pasport_Readers;
        private TextBox Seria_Readers;
        private TextBox Otchestvo_Readers;
        private TextBox Name_Readers;
        private Label label4;
        private TextBox Familia_Readers;
        private Label label3;
        private Label label7;
        private Label label5;
        private Label label6;
        private TextBox Author_Readers;
        private TextBox Name_Book_Readers;
        private TextBox Email_Readers;
        private TextBox Number_Phone_Readers;
        private Label label10;
        private Label label2;
        private Label label9;
        private Label label8;
        private DateTimePicker Date_vozvrata_;
        private DateTimePicker Data_Vydachi_Readers;
        private Label label12;
        private Label label11;
    }
}
