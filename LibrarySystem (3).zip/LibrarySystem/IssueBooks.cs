﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class IssueBooks : UserControl
    {
        private string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;";

        public IssueBooks()
        {
            InitializeComponent();
            LoadBooks();
            LoadReaders();
        }

        private void LoadBooks()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = @"SELECT ID, Название_книги, Автор, Дата_публикации, 
                                  CASE 
                                     WHEN EXISTS (SELECT 1 FROM BookIssues WHERE ID_Книги = Books.ID AND Дата_возврата IS NULL)
                                     THEN 'Выдана'
                                     ELSE 'Не выдана'
                                  END AS Статус
                               FROM Books";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    All_Issue_Books.DataSource = dt;
                    All_Issue_Books.Columns["ID"].Visible = false;
                    All_Issue_Books.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
        }

        private void LoadReaders()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ID_Читателя, Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта, Номер_телефона, Электронная_почта FROM Readers";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    Readers_IssueBooks.DataSource = dt;
                    Readers_IssueBooks.Columns["ID_Читателя"].Visible = false;
                    Readers_IssueBooks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
        }

        private void Readers_IssueBooks_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < Readers_IssueBooks.Rows.Count)
            {
                DataGridViewRow row = Readers_IssueBooks.Rows[e.RowIndex];
                Familia_Readers.Text = row.Cells["Фамилия"].Value?.ToString();
                Name_Readers.Text = row.Cells["Имя"].Value?.ToString();
                Otchestvo_Readers.Text = row.Cells["Отчество"].Value?.ToString();
                Seria_Readers.Text = row.Cells["Серия_паспорта"].Value?.ToString();
                Number_pasport_Readers.Text = row.Cells["Номер_паспорта"].Value?.ToString();
                Number_Phone_Readers.Text = row.Cells["Номер_телефона"].Value?.ToString();
                Email_Readers.Text = row.Cells["Электронная_почта"].Value?.ToString();
            }
        }

        private void All_Issue_Books_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < All_Issue_Books.Rows.Count)
            {
                DataGridViewRow row = All_Issue_Books.Rows[e.RowIndex];
                Name_Book_Readers.Text = row.Cells["Название_книги"].Value?.ToString();
                Author_Readers.Text = row.Cells["Автор"].Value?.ToString();

                if (DateTime.TryParse(row.Cells["Дата_публикации"].Value?.ToString(), out DateTime date))
                {
                    Data_Vydachi_Readers.Value = date;
                }

            }
        }


        private void SearchReaders()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ID_Читателя, Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта, Номер_телефона, Электронная_почта FROM Readers WHERE ";
                string conditions = "";

                if (!string.IsNullOrEmpty(Familia_Readers.Text))
                    conditions += $"Фамилия LIKE '%{Familia_Readers.Text}%' OR ";
                if (!string.IsNullOrEmpty(Name_Readers.Text))
                    conditions += $"Имя LIKE '%{Name_Readers.Text}%' OR ";
                if (!string.IsNullOrEmpty(Otchestvo_Readers.Text))
                    conditions += $"Отчество LIKE '%{Otchestvo_Readers.Text}%' OR ";
                if (!string.IsNullOrEmpty(Seria_Readers.Text))
                    conditions += $"Серия_паспорта LIKE '%{Seria_Readers.Text}%' OR ";
                if (!string.IsNullOrEmpty(Number_pasport_Readers.Text))
                    conditions += $"Номер_паспорта LIKE '%{Number_pasport_Readers.Text}%' OR ";
                if (!string.IsNullOrEmpty(Number_Phone_Readers.Text))
                    conditions += $"Номер_телефона LIKE '%{Number_Phone_Readers.Text}%' OR ";
                if (!string.IsNullOrEmpty(Email_Readers.Text))
                    conditions += $"Электронная_почта LIKE '%{Email_Readers.Text}%' OR ";

                if (conditions.EndsWith(" OR "))
                    conditions = conditions.Substring(0, conditions.Length - 4);

                if (string.IsNullOrEmpty(conditions))
                {
                    LoadReaders();
                    return;
                }


                query += conditions;


                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    Readers_IssueBooks.DataSource = dt;
                    Readers_IssueBooks.Columns["ID_Читателя"].Visible = false;
                    Readers_IssueBooks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
        }

        private void SearchBooks()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = @"SELECT ID, Название_книги, Автор, Дата_публикации, 
                                  CASE 
                                     WHEN EXISTS (SELECT 1 FROM BookIssues WHERE ID_Книги = Books.ID AND Дата_возврата IS NULL)
                                     THEN 'Выдана'
                                     ELSE 'Не выдана'
                                  END AS Статус
                               FROM Books WHERE ";
                string conditions = "";

                if (!string.IsNullOrEmpty(Name_Book_Readers.Text))
                    conditions += $"Название_книги LIKE '%{Name_Book_Readers.Text}%' OR ";
                if (!string.IsNullOrEmpty(Author_Readers.Text))
                    conditions += $"Автор LIKE '%{Author_Readers.Text}%' OR ";

                if (Data_Vydachi_Readers.Value != DateTime.MinValue)
                    conditions += $"Дата_публикации = '{Data_Vydachi_Readers.Value.ToString("yyyy-MM-dd")}' OR ";


                if (conditions.EndsWith(" OR "))
                    conditions = conditions.Substring(0, conditions.Length - 4);

                if (string.IsNullOrEmpty(conditions))
                {
                    LoadBooks();
                    return;
                }
                query += conditions;

                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    All_Issue_Books.DataSource = dt;
                    All_Issue_Books.Columns["ID"].Visible = false;
                    All_Issue_Books.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
        }


        private void Familia_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchReaders();
        }

        private void Name_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchReaders();
        }

        private void Otchestvo_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchReaders();
        }

        private void Seria_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchReaders();
        }

        private void Number_pasport_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchReaders();
        }

        private void Number_Phone_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchReaders();
        }

        private void Email_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchReaders();
        }

        private void Name_Book_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchBooks();
        }

        private void Author_Readers_TextChanged(object sender, EventArgs e)
        {
            SearchBooks();
        }

        private void Data_Vydachi_Readers_ValueChanged(object sender, EventArgs e)
        {
            SearchBooks();
        }

        private void Clear_Click_1(object sender, EventArgs e)
        {
            Familia_Readers.Text = "";
            Name_Readers.Text = "";
            Otchestvo_Readers.Text = "";
            Seria_Readers.Text = "";
            Number_pasport_Readers.Text = "";
            Number_Phone_Readers.Text = "";
            Email_Readers.Text = "";
            Name_Book_Readers.Text = "";
            Author_Readers.Text = "";
            Data_Vydachi_Readers.Value = DateTime.Now;
            LoadBooks();
            LoadReaders();
        }
    }
}
