﻿namespace LibrarySystem
{
    partial class AddBooks
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            panel1 = new Panel();
            AddBook_clearBtn = new Button();
            AddBook_deleteBtn = new Button();
            AddBook_Status = new ComboBox();
            label3 = new Label();
            AddBook_published = new DateTimePicker();
            label2 = new Label();
            AddBook_updateBtn = new Button();
            AddBook_addBtn = new Button();
            label7 = new Label();
            AddBook_Author = new TextBox();
            label6 = new Label();
            AddBook_bookTitle = new TextBox();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(label1);
            panel2.Location = new Point(316, 19);
            panel2.Name = "panel2";
            panel2.Size = new Size(547, 526);
            panel2.TabIndex = 3;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 57);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(513, 447);
            dataGridView1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(13, 12);
            label1.Name = "label1";
            label1.Size = new Size(262, 31);
            label1.TabIndex = 0;
            label1.Text = "Все добавленные книги";
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(AddBook_clearBtn);
            panel1.Controls.Add(AddBook_deleteBtn);
            panel1.Controls.Add(AddBook_Status);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(AddBook_published);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(AddBook_updateBtn);
            panel1.Controls.Add(AddBook_addBtn);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(AddBook_Author);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(AddBook_bookTitle);
            panel1.Location = new Point(17, 19);
            panel1.Name = "panel1";
            panel1.Size = new Size(278, 526);
            panel1.TabIndex = 2;
            // 
            // AddBook_clearBtn
            // 
            AddBook_clearBtn.BackColor = Color.SeaGreen;
            AddBook_clearBtn.Cursor = Cursors.Hand;
            AddBook_clearBtn.FlatStyle = FlatStyle.Flat;
            AddBook_clearBtn.ForeColor = Color.White;
            AddBook_clearBtn.Location = new Point(156, 415);
            AddBook_clearBtn.Name = "AddBook_clearBtn";
            AddBook_clearBtn.Size = new Size(114, 39);
            AddBook_clearBtn.TabIndex = 23;
            AddBook_clearBtn.Text = "ОЧИСТИТЬ";
            AddBook_clearBtn.UseVisualStyleBackColor = false;
            AddBook_clearBtn.Click += AddBook_clearBtn_Click;
            // 
            // AddBook_deleteBtn
            // 
            AddBook_deleteBtn.BackColor = Color.SeaGreen;
            AddBook_deleteBtn.Cursor = Cursors.Hand;
            AddBook_deleteBtn.FlatStyle = FlatStyle.Flat;
            AddBook_deleteBtn.ForeColor = Color.White;
            AddBook_deleteBtn.Location = new Point(21, 415);
            AddBook_deleteBtn.Name = "AddBook_deleteBtn";
            AddBook_deleteBtn.Size = new Size(114, 39);
            AddBook_deleteBtn.TabIndex = 22;
            AddBook_deleteBtn.Text = "УДАЛИТЬ";
            AddBook_deleteBtn.UseVisualStyleBackColor = false;
            AddBook_deleteBtn.Click += AddBook_deleteBtn_Click;
            // 
            // AddBook_Status
            // 
            AddBook_Status.FormattingEnabled = true;
            AddBook_Status.Items.AddRange(new object[] { "Возвращена", "Не возвращена" });
            AddBook_Status.Location = new Point(107, 230);
            AddBook_Status.Name = "AddBook_Status";
            AddBook_Status.Size = new Size(160, 28);
            AddBook_Status.TabIndex = 21;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(45, 233);
            label3.Name = "label3";
            label3.Size = new Size(55, 20);
            label3.TabIndex = 20;
            label3.Text = "Статус:";
            // 
            // AddBook_published
            // 
            AddBook_published.Location = new Point(107, 182);
            AddBook_published.Name = "AddBook_published";
            AddBook_published.Size = new Size(160, 27);
            AddBook_published.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 169);
            label2.Name = "label2";
            label2.Size = new Size(96, 40);
            label2.TabIndex = 18;
            label2.Text = "Дата \r\nпубликации:";
            // 
            // AddBook_updateBtn
            // 
            AddBook_updateBtn.BackColor = Color.SeaGreen;
            AddBook_updateBtn.Cursor = Cursors.Hand;
            AddBook_updateBtn.FlatStyle = FlatStyle.Flat;
            AddBook_updateBtn.ForeColor = Color.White;
            AddBook_updateBtn.Location = new Point(158, 353);
            AddBook_updateBtn.Name = "AddBook_updateBtn";
            AddBook_updateBtn.Size = new Size(112, 39);
            AddBook_updateBtn.TabIndex = 17;
            AddBook_updateBtn.Text = "ИЗМЕНИТЬ";
            AddBook_updateBtn.UseVisualStyleBackColor = false;
            AddBook_updateBtn.Click += AddBook_updateBtn_Click;
            // 
            // AddBook_addBtn
            // 
            AddBook_addBtn.BackColor = Color.SeaGreen;
            AddBook_addBtn.Cursor = Cursors.Hand;
            AddBook_addBtn.FlatStyle = FlatStyle.Flat;
            AddBook_addBtn.ForeColor = Color.White;
            AddBook_addBtn.Location = new Point(21, 353);
            AddBook_addBtn.Name = "AddBook_addBtn";
            AddBook_addBtn.Size = new Size(114, 39);
            AddBook_addBtn.TabIndex = 16;
            AddBook_addBtn.Text = "ДОБАВИТЬ";
            AddBook_addBtn.UseVisualStyleBackColor = false;
            AddBook_addBtn.Click += AddBook_addBtn_Click_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(46, 131);
            label7.Name = "label7";
            label7.Size = new Size(54, 20);
            label7.TabIndex = 13;
            label7.Text = "Автор:";
            // 
            // AddBook_Author
            // 
            AddBook_Author.Location = new Point(106, 128);
            AddBook_Author.Name = "AddBook_Author";
            AddBook_Author.Size = new Size(161, 27);
            AddBook_Author.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(21, 72);
            label6.Name = "label6";
            label6.Size = new Size(81, 40);
            label6.TabIndex = 11;
            label6.Text = "Название \r\n      книги:";
            // 
            // AddBook_bookTitle
            // 
            AddBook_bookTitle.Location = new Point(106, 85);
            AddBook_bookTitle.Name = "AddBook_bookTitle";
            AddBook_bookTitle.Size = new Size(161, 27);
            AddBook_bookTitle.TabIndex = 10;
            // 
            // AddBooks
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "AddBooks";
            Size = new Size(880, 565);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private DataGridView dataGridView1;
        private Label label1;
        private Panel panel1;
        private ComboBox AddBook_Status;
        private Label label3;
        private DateTimePicker AddBook_published;
        private Label label2;
        private Button AddBook_updateBtn;
        private Button AddBook_addBtn;
        private Label label7;
        private TextBox AddBook_Author;
        private Label label6;
        private TextBox AddBook_bookTitle;
        private Button AddBook_clearBtn;
        private Button AddBook_deleteBtn;
    }
}
