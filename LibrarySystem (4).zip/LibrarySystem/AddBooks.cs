﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class AddBooks : UserControl
    {
        private string connectionString = @"Data Source=E:\LibrSystem.db"; //Измените путь к базе данных

        public AddBooks()
        {
            InitializeComponent();
            LoadBooks();

            //Заполняем ComboBox (при необходимости)
            AddBook_Status.Items.Add("В наличии");
            AddBook_Status.Items.Add("Выдана");
            AddBook_Status.Items.Add("Зарезервирована");
            AddBook_Status.SelectedIndex = 0; //Установка значения по умолчанию

            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect; //Разрешаем выбор только целых строк
            dataGridView1.MultiSelect = false; //Запрещаем множественный выбор
            dataGridView1.SelectionChanged += DataGridView1_SelectionChanged; // Подписка на событие
            dataGridView1.ReadOnly = true; // Запрещаем редактирование всей таблицы

            // Дополнительная проверка и запрет редактирования для каждой колонки.
            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.ReadOnly = true;
            }
        }

        // Обработчик события SelectionChanged для DataGridView
        private void DataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Проверяем, существуют ли столбцы перед обращением к ним
                if (selectedRow.Cells["Название_книги"] != null && selectedRow.Cells["Автор"] != null && selectedRow.Cells["Дата_публикации"] != null && selectedRow.Cells["Статус"] != null)
                {
                    AddBook_bookTitle.Text = selectedRow.Cells["Название_книги"].Value.ToString();
                    AddBook_Author.Text = selectedRow.Cells["Автор"].Value.ToString();
                    if (DateTime.TryParse(selectedRow.Cells["Дата_публикации"].Value.ToString(), out DateTime publishedDate))
                    {
                        AddBook_published.Value = publishedDate;
                    }
                    AddBook_Status.SelectedItem = selectedRow.Cells["Статус"].Value.ToString();
                }
            }
            else
            {
                Clear1Fields(); // Очищаем поля, если ничего не выбрано
            }
        }


        private void AddBook_addBtn_Click_1(object sender, EventArgs e)
        {
            string bookTitle = AddBook_bookTitle.Text;
            string author = AddBook_Author.Text;
            DateTime publishedDate = AddBook_published.Value;
            string status = AddBook_Status.SelectedItem?.ToString() ?? "";


            if (string.IsNullOrEmpty(bookTitle) || string.IsNullOrEmpty(author) || string.IsNullOrEmpty(status))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    using (SQLiteCommand command = new SQLiteCommand(connection))
                    {
                        //Проверка существования таблицы
                        using (SQLiteCommand checkTableCommand = new SQLiteCommand("SELECT name FROM sqlite_master WHERE type='table' AND name='Books'", connection))
                        {
                            var result = checkTableCommand.ExecuteScalar();
                            if (result == null)
                            {
                                MessageBox.Show("Таблица 'Books' не найдена в базе данных. Создайте таблицу.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = @"INSERT INTO Books (Название_книги, Автор, Дата_публикации, Статус, Дата_добавления)
                                                VALUES (@bookTitle, @author, @publishedDate, @status, @currentDate)";
                        command.Parameters.AddWithValue("@bookTitle", bookTitle);
                        command.Parameters.AddWithValue("@author", author);
                        command.Parameters.AddWithValue("@publishedDate", publishedDate);
                        command.Parameters.AddWithValue("@status", status);
                        command.Parameters.AddWithValue("@currentDate", DateTime.Now);
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Книга добавлена успешно!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear1Fields();
                LoadBooks();
            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show($"Ошибка при добавлении книги: {sqlex.Message}\nКод ошибки: {sqlex.ErrorCode}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении книги: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadBooks()
        {
            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter("SELECT Название_книги, Автор, Дата_публикации, Статус FROM Books", connection))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {sqlex.Message}\nКод ошибки: {sqlex.ErrorCode}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Clear1Fields()
        {
            AddBook_bookTitle.Clear();
            AddBook_Author.Clear();
            AddBook_published.Value = DateTime.Now;
            AddBook_Status.SelectedIndex = 0; // Устанавливаем значение по умолчанию для ComboBox
        }

        private void AddBook_deleteBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку для удаления.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            string bookTitleToDelete = selectedRow.Cells["Название_книги"].Value.ToString(); // Предполагается, что столбец с названием книги называется "Название_книги"

            if (MessageBox.Show($"Вы действительно хотите удалить книгу '{bookTitleToDelete}'?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        using (SQLiteCommand command = new SQLiteCommand(connection))
                        {
                            command.CommandText = "DELETE FROM Books WHERE Название_книги = @bookTitle";
                            command.Parameters.AddWithValue("@bookTitle", bookTitleToDelete);
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Книга удалена успешно!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBooks(); // Обновляем DataGridView
                }
                catch (SQLiteException sqlex)
                {
                    MessageBox.Show($"Ошибка при удалении книги: {sqlex.Message}\nКод ошибки: {sqlex.ErrorCode}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении книги: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void AddBook_updateBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку для изменения.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            string bookTitleToUpdate = selectedRow.Cells["Название_книги"].Value.ToString();
            string updatedTitle = AddBook_bookTitle.Text;
            string updatedAuthor = AddBook_Author.Text;
            DateTime updatedPublishedDate = AddBook_published.Value;
            string updatedStatus = AddBook_Status.SelectedItem?.ToString() ?? "";


            if (string.IsNullOrEmpty(updatedTitle) || string.IsNullOrEmpty(updatedAuthor) || string.IsNullOrEmpty(updatedStatus))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    using (SQLiteCommand command = new SQLiteCommand(connection))
                    {
                        command.CommandText = @"UPDATE Books 
                                                SET Название_книги = @updatedTitle, 
                                                    Автор = @updatedAuthor, 
                                                    Дата_публикации = @updatedPublishedDate, 
                                                    Статус = @updatedStatus
                                                WHERE Название_книги = @bookTitleToUpdate";
                        command.Parameters.AddWithValue("@updatedTitle", updatedTitle);
                        command.Parameters.AddWithValue("@updatedAuthor", updatedAuthor);
                        command.Parameters.AddWithValue("@updatedPublishedDate", updatedPublishedDate);
                        command.Parameters.AddWithValue("@updatedStatus", updatedStatus);
                        command.Parameters.AddWithValue("@bookTitleToUpdate", bookTitleToUpdate);
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Книга обновлена успешно!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadBooks();
                Clear1Fields();
            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show($"Ошибка при обновлении книги: {sqlex.Message}\nКод ошибки: {sqlex.ErrorCode}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при обновлении книги: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddBook_clearBtn_Click(object sender, EventArgs e)
        {
            Clear1Fields();
        }
    }
}
