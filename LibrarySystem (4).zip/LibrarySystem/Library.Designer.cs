﻿namespace LibrarySystem
{
    partial class Library
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            Library_Window = new DataGridView();
            Library_UpdateBtn = new Button();
            Library_DeleteBtn = new Button();
            panel2 = new Panel();
            Library_Email = new TextBox();
            Library_Number_Phone = new TextBox();
            label9 = new Label();
            label8 = new Label();
            Library_Number = new TextBox();
            Library_Seria = new TextBox();
            label7 = new Label();
            label6 = new Label();
            Library_Otchestvo = new TextBox();
            Library_Name = new TextBox();
            label4 = new Label();
            Library_Familia = new TextBox();
            label3 = new Label();
            label5 = new Label();
            Library_AddBtn = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Library_Window).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonHighlight;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(Library_Window);
            panel1.ForeColor = SystemColors.ControlText;
            panel1.Location = new Point(14, 13);
            panel1.Name = "panel1";
            panel1.Size = new Size(854, 307);
            panel1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(16, 17);
            label1.Name = "label1";
            label1.Size = new Size(131, 23);
            label1.TabIndex = 1;
            label1.Text = "Библиотекари";
            // 
            // Library_Window
            // 
            Library_Window.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Library_Window.Location = new Point(16, 50);
            Library_Window.Name = "Library_Window";
            Library_Window.RowHeadersWidth = 51;
            Library_Window.Size = new Size(823, 240);
            Library_Window.TabIndex = 0;
            // 
            // Library_UpdateBtn
            // 
            Library_UpdateBtn.BackColor = Color.SeaGreen;
            Library_UpdateBtn.FlatStyle = FlatStyle.Flat;
            Library_UpdateBtn.ForeColor = Color.White;
            Library_UpdateBtn.Location = new Point(391, 180);
            Library_UpdateBtn.Name = "Library_UpdateBtn";
            Library_UpdateBtn.Size = new Size(99, 29);
            Library_UpdateBtn.TabIndex = 25;
            Library_UpdateBtn.Text = "ИЗМЕНИТЬ";
            Library_UpdateBtn.UseVisualStyleBackColor = false;
            Library_UpdateBtn.Click += Library_UpdateBtn_Click;
            // 
            // Library_DeleteBtn
            // 
            Library_DeleteBtn.BackColor = Color.SeaGreen;
            Library_DeleteBtn.FlatStyle = FlatStyle.Flat;
            Library_DeleteBtn.ForeColor = Color.White;
            Library_DeleteBtn.Location = new Point(505, 180);
            Library_DeleteBtn.Name = "Library_DeleteBtn";
            Library_DeleteBtn.Size = new Size(99, 29);
            Library_DeleteBtn.TabIndex = 24;
            Library_DeleteBtn.Text = "УДАЛИТЬ";
            Library_DeleteBtn.UseVisualStyleBackColor = false;
            Library_DeleteBtn.Click += Library_DeleteBtn_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(Library_Email);
            panel2.Controls.Add(Library_Number_Phone);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(Library_Number);
            panel2.Controls.Add(Library_Seria);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(Library_Otchestvo);
            panel2.Controls.Add(Library_Name);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(Library_Familia);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(Library_AddBtn);
            panel2.Controls.Add(Library_UpdateBtn);
            panel2.Controls.Add(Library_DeleteBtn);
            panel2.Location = new Point(14, 326);
            panel2.Name = "panel2";
            panel2.Size = new Size(854, 223);
            panel2.TabIndex = 2;
            // 
            // Library_Email
            // 
            Library_Email.Location = new Point(710, 12);
            Library_Email.Name = "Library_Email";
            Library_Email.Size = new Size(129, 27);
            Library_Email.TabIndex = 62;
            // 
            // Library_Number_Phone
            // 
            Library_Number_Phone.Location = new Point(498, 132);
            Library_Number_Phone.Name = "Library_Number_Phone";
            Library_Number_Phone.Size = new Size(105, 27);
            Library_Number_Phone.TabIndex = 61;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(610, 12);
            label9.Name = "label9";
            label9.Size = new Size(103, 40);
            label9.TabIndex = 60;
            label9.Text = "Электронная \r\nпочта:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(362, 135);
            label8.Name = "label8";
            label8.Size = new Size(130, 20);
            label8.TabIndex = 59;
            label8.Text = "Номер телефона:";
            // 
            // Library_Number
            // 
            Library_Number.Location = new Point(499, 72);
            Library_Number.Name = "Library_Number";
            Library_Number.Size = new Size(105, 27);
            Library_Number.TabIndex = 58;
            // 
            // Library_Seria
            // 
            Library_Seria.Location = new Point(499, 12);
            Library_Seria.Name = "Library_Seria";
            Library_Seria.Size = new Size(105, 27);
            Library_Seria.TabIndex = 57;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(368, 75);
            label7.Name = "label7";
            label7.Size = new Size(129, 20);
            label7.TabIndex = 56;
            label7.Text = "Номер паспорта:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(373, 15);
            label6.Name = "label6";
            label6.Size = new Size(124, 20);
            label6.TabIndex = 55;
            label6.Text = "Серия паспорта:";
            // 
            // Library_Otchestvo
            // 
            Library_Otchestvo.Location = new Point(133, 129);
            Library_Otchestvo.Name = "Library_Otchestvo";
            Library_Otchestvo.Size = new Size(145, 27);
            Library_Otchestvo.TabIndex = 52;
            // 
            // Library_Name
            // 
            Library_Name.Location = new Point(133, 72);
            Library_Name.Name = "Library_Name";
            Library_Name.Size = new Size(145, 27);
            Library_Name.TabIndex = 51;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 12);
            label4.Name = "label4";
            label4.Size = new Size(111, 40);
            label4.TabIndex = 48;
            label4.Text = "Фамилия \r\nбиблиотекаря:";
            // 
            // Library_Familia
            // 
            Library_Familia.Location = new Point(133, 12);
            Library_Familia.Name = "Library_Familia";
            Library_Familia.Size = new Size(145, 27);
            Library_Familia.TabIndex = 50;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 72);
            label3.Name = "label3";
            label3.Size = new Size(111, 40);
            label3.TabIndex = 47;
            label3.Text = "Имя \r\nбиблиотекаря:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(16, 132);
            label5.Name = "label5";
            label5.Size = new Size(111, 40);
            label5.TabIndex = 49;
            label5.Text = "Отчество \r\nбиблиотекаря:";
            // 
            // Library_AddBtn
            // 
            Library_AddBtn.BackColor = Color.SeaGreen;
            Library_AddBtn.FlatStyle = FlatStyle.Flat;
            Library_AddBtn.ForeColor = Color.White;
            Library_AddBtn.Location = new Point(277, 180);
            Library_AddBtn.Name = "Library_AddBtn";
            Library_AddBtn.Size = new Size(99, 29);
            Library_AddBtn.TabIndex = 26;
            Library_AddBtn.Text = "ДОБАВИТЬ";
            Library_AddBtn.UseVisualStyleBackColor = false;
            Library_AddBtn.Click += Library_AddBtn_Click;
            // 
            // Library
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Library";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Library_Window).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private DataGridView Library_Window;
        private Button Library_UpdateBtn;
        private Button Library_DeleteBtn;
        private Panel panel2;
        private Button Library_AddBtn;
        private TextBox Library_Otchestvo;
        private TextBox Library_Name;
        private Label label4;
        private TextBox Library_Familia;
        private Label label3;
        private Label label5;
        private TextBox Library_Email;
        private TextBox Library_Number_Phone;
        private Label label9;
        private Label label8;
        private TextBox Library_Number;
        private TextBox Library_Seria;
        private Label label7;
        private Label label6;
    }
}
