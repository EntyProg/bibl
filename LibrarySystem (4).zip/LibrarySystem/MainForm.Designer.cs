﻿namespace LibrarySystem
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            panel1 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            Issue_book_btn = new Button();
            library_btn = new Button();
            ReadersBtn = new Button();
            Return_book_btn = new Button();
            Jurnal_SobytiyBtn = new Button();
            label4 = new Label();
            logout_btn = new Button();
            add_book_btn = new Button();
            dashboard_btn = new Button();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            returnBooks1 = new ReturnBooks();
            issueBooks1 = new IssueBooks();
            addBooks1 = new AddBooks();
            dashboard1 = new Dashboard();
            mainForm_Readers1 = new MainForm_Readers();
            library1 = new Library();
            jurnalSobytiy1 = new JurnalSobytiy();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.SeaGreen;
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1100, 35);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.SeaGreen;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.White;
            label2.Location = new Point(8, 5);
            label2.Name = "label2";
            label2.Size = new Size(212, 25);
            label2.TabIndex = 2;
            label2.Text = "Городская библиотека";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Arial Narrow", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ForeColor = Color.White;
            label1.Location = new Point(1076, 9);
            label1.Name = "label1";
            label1.Size = new Size(17, 20);
            label1.TabIndex = 1;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.SeaGreen;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(Issue_book_btn);
            panel2.Controls.Add(library_btn);
            panel2.Controls.Add(ReadersBtn);
            panel2.Controls.Add(Return_book_btn);
            panel2.Controls.Add(Jurnal_SobytiyBtn);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(logout_btn);
            panel2.Controls.Add(add_book_btn);
            panel2.Controls.Add(dashboard_btn);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 35);
            panel2.Name = "panel2";
            panel2.Size = new Size(220, 565);
            panel2.TabIndex = 1;
            // 
            // Issue_book_btn
            // 
            Issue_book_btn.Cursor = Cursors.Hand;
            Issue_book_btn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            Issue_book_btn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            Issue_book_btn.FlatStyle = FlatStyle.Flat;
            Issue_book_btn.ForeColor = Color.White;
            Issue_book_btn.Image = (Image)resources.GetObject("Issue_book_btn.Image");
            Issue_book_btn.ImageAlign = ContentAlignment.MiddleLeft;
            Issue_book_btn.Location = new Point(11, 270);
            Issue_book_btn.Name = "Issue_book_btn";
            Issue_book_btn.Size = new Size(200, 45);
            Issue_book_btn.TabIndex = 11;
            Issue_book_btn.Text = "ВЫДАТЬ КНИГУ";
            Issue_book_btn.TextAlign = ContentAlignment.MiddleRight;
            Issue_book_btn.UseVisualStyleBackColor = true;
            Issue_book_btn.Click += Issue_book_btn_Click;
            // 
            // library_btn
            // 
            library_btn.Cursor = Cursors.Hand;
            library_btn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            library_btn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            library_btn.FlatStyle = FlatStyle.Flat;
            library_btn.ForeColor = Color.White;
            library_btn.Image = (Image)resources.GetObject("library_btn.Image");
            library_btn.ImageAlign = ContentAlignment.MiddleLeft;
            library_btn.Location = new Point(11, 423);
            library_btn.Name = "library_btn";
            library_btn.Size = new Size(200, 45);
            library_btn.TabIndex = 10;
            library_btn.Text = "БИБЛИОТЕКАРИ";
            library_btn.TextAlign = ContentAlignment.MiddleRight;
            library_btn.UseVisualStyleBackColor = true;
            library_btn.Click += library_btn_Click;
            // 
            // ReadersBtn
            // 
            ReadersBtn.Cursor = Cursors.Hand;
            ReadersBtn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            ReadersBtn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            ReadersBtn.FlatStyle = FlatStyle.Flat;
            ReadersBtn.ForeColor = Color.White;
            ReadersBtn.Image = (Image)resources.GetObject("ReadersBtn.Image");
            ReadersBtn.ImageAlign = ContentAlignment.MiddleLeft;
            ReadersBtn.Location = new Point(11, 372);
            ReadersBtn.Name = "ReadersBtn";
            ReadersBtn.Size = new Size(200, 45);
            ReadersBtn.TabIndex = 9;
            ReadersBtn.Text = "ЧИТАТЕЛИ";
            ReadersBtn.TextAlign = ContentAlignment.MiddleRight;
            ReadersBtn.UseVisualStyleBackColor = true;
            ReadersBtn.Click += ReadersBtn_Click;
            // 
            // Return_book_btn
            // 
            Return_book_btn.Cursor = Cursors.Hand;
            Return_book_btn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            Return_book_btn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            Return_book_btn.FlatStyle = FlatStyle.Flat;
            Return_book_btn.ForeColor = Color.White;
            Return_book_btn.Image = (Image)resources.GetObject("Return_book_btn.Image");
            Return_book_btn.ImageAlign = ContentAlignment.MiddleLeft;
            Return_book_btn.Location = new Point(11, 321);
            Return_book_btn.Name = "Return_book_btn";
            Return_book_btn.Size = new Size(200, 45);
            Return_book_btn.TabIndex = 5;
            Return_book_btn.Text = "ВЕРНУТЬ КНИГУ";
            Return_book_btn.TextAlign = ContentAlignment.MiddleRight;
            Return_book_btn.UseVisualStyleBackColor = true;
            Return_book_btn.Click += Return_book_btn_Click;
            // 
            // Jurnal_SobytiyBtn
            // 
            Jurnal_SobytiyBtn.Cursor = Cursors.Hand;
            Jurnal_SobytiyBtn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            Jurnal_SobytiyBtn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            Jurnal_SobytiyBtn.FlatStyle = FlatStyle.Flat;
            Jurnal_SobytiyBtn.ForeColor = Color.White;
            Jurnal_SobytiyBtn.Image = (Image)resources.GetObject("Jurnal_SobytiyBtn.Image");
            Jurnal_SobytiyBtn.ImageAlign = ContentAlignment.MiddleLeft;
            Jurnal_SobytiyBtn.Location = new Point(11, 474);
            Jurnal_SobytiyBtn.Name = "Jurnal_SobytiyBtn";
            Jurnal_SobytiyBtn.Size = new Size(200, 45);
            Jurnal_SobytiyBtn.TabIndex = 8;
            Jurnal_SobytiyBtn.Text = "ЖУРНАЛ СОБЫТИЙ";
            Jurnal_SobytiyBtn.TextAlign = ContentAlignment.MiddleRight;
            Jurnal_SobytiyBtn.UseVisualStyleBackColor = true;
            Jurnal_SobytiyBtn.Click += Jurnal_SobytiyBtn_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.White;
            label4.Location = new Point(52, 532);
            label4.Name = "label4";
            label4.Size = new Size(53, 20);
            label4.TabIndex = 7;
            label4.Text = "Выход";
            // 
            // logout_btn
            // 
            logout_btn.Cursor = Cursors.Hand;
            logout_btn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            logout_btn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            logout_btn.FlatStyle = FlatStyle.Flat;
            logout_btn.ForeColor = Color.White;
            logout_btn.Image = (Image)resources.GetObject("logout_btn.Image");
            logout_btn.Location = new Point(11, 525);
            logout_btn.Name = "logout_btn";
            logout_btn.Size = new Size(35, 35);
            logout_btn.TabIndex = 6;
            logout_btn.UseVisualStyleBackColor = true;
            logout_btn.Click += logout_btn_Click;
            // 
            // add_book_btn
            // 
            add_book_btn.Cursor = Cursors.Hand;
            add_book_btn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            add_book_btn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            add_book_btn.FlatStyle = FlatStyle.Flat;
            add_book_btn.ForeColor = Color.White;
            add_book_btn.Image = (Image)resources.GetObject("add_book_btn.Image");
            add_book_btn.ImageAlign = ContentAlignment.MiddleLeft;
            add_book_btn.Location = new Point(11, 219);
            add_book_btn.Name = "add_book_btn";
            add_book_btn.Size = new Size(200, 45);
            add_book_btn.TabIndex = 3;
            add_book_btn.Text = "ДОБАВИТЬ КНИГУ";
            add_book_btn.TextAlign = ContentAlignment.MiddleRight;
            add_book_btn.UseVisualStyleBackColor = true;
            add_book_btn.Click += add_book_btn_Click;
            // 
            // dashboard_btn
            // 
            dashboard_btn.Cursor = Cursors.Hand;
            dashboard_btn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            dashboard_btn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            dashboard_btn.FlatStyle = FlatStyle.Flat;
            dashboard_btn.ForeColor = Color.White;
            dashboard_btn.Location = new Point(11, 168);
            dashboard_btn.Name = "dashboard_btn";
            dashboard_btn.Size = new Size(200, 45);
            dashboard_btn.TabIndex = 2;
            dashboard_btn.Text = "ПАНЕЛЬ МОНИТОРИНГА";
            dashboard_btn.TextAlign = ContentAlignment.MiddleRight;
            dashboard_btn.UseVisualStyleBackColor = true;
            dashboard_btn.Click += dashboard_btn_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.SeaGreen;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.ForeColor = Color.White;
            label3.Location = new Point(28, 108);
            label3.Name = "label3";
            label3.Size = new Size(179, 46);
            label3.TabIndex = 1;
            label3.Text = "Добро пожаловать, \r\n  Администратор!";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.books_library_study_icon_150963;
            pictureBox1.Location = new Point(63, 15);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // returnBooks1
            // 
            returnBooks1.Location = new Point(218, 35);
            returnBooks1.Name = "returnBooks1";
            returnBooks1.Size = new Size(1100, 706);
            returnBooks1.TabIndex = 2;
            // 
            // issueBooks1
            // 
            issueBooks1.Location = new Point(218, 35);
            issueBooks1.Name = "issueBooks1";
            issueBooks1.Size = new Size(1100, 706);
            issueBooks1.TabIndex = 11;
            // 
            // addBooks1
            // 
            addBooks1.Location = new Point(218, 35);
            addBooks1.Name = "addBooks1";
            addBooks1.Size = new Size(1100, 706);
            addBooks1.TabIndex = 11;
            // 
            // dashboard1
            // 
            dashboard1.Location = new Point(218, 35);
            dashboard1.Name = "dashboard1";
            dashboard1.Size = new Size(1100, 706);
            dashboard1.TabIndex = 11;
            // 
            // mainForm_Readers1
            // 
            mainForm_Readers1.Location = new Point(218, 35);
            mainForm_Readers1.Name = "mainForm_Readers1";
            mainForm_Readers1.Size = new Size(1100, 706);
            mainForm_Readers1.TabIndex = 12;
            // 
            // library1
            // 
            library1.Location = new Point(218, 35);
            library1.Name = "library1";
            library1.Size = new Size(1100, 706);
            library1.TabIndex = 13;
            // 
            // jurnalSobytiy1
            // 
            jurnalSobytiy1.Location = new Point(218, 32);
            jurnalSobytiy1.Name = "jurnalSobytiy1";
            jurnalSobytiy1.Size = new Size(1100, 706);
            jurnalSobytiy1.TabIndex = 14;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1100, 600);
            Controls.Add(jurnalSobytiy1);
            Controls.Add(library1);
            Controls.Add(mainForm_Readers1);
            Controls.Add(dashboard1);
            Controls.Add(addBooks1);
            Controls.Add(issueBooks1);
            Controls.Add(returnBooks1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label2;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label3;
        private Button dashboard_btn;
        private Button add_book_btn;
        private Button Return_book_btn;
        private Button logout_btn;
        private Label label4;
        private Button Jurnal_SobytiyBtn;
        private Button library_btn;
        private Button ReadersBtn;
        private ReturnBooks returnBooks1;
        private IssueBooks issueBooks1;
        private AddBooks addBooks1;
        private Dashboard dashboard1;
        private Button Issue_book_btn;
        private MainForm_Readers mainForm_Readers1;
        private Library library1;
        private JurnalSobytiy jurnalSobytiy1;
    }
}