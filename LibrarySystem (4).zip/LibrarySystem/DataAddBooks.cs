﻿using System;
using System.Data.SQLite;

namespace LibrarySystem
{
    internal class DataAddBooks
    {
        private string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;"; // Путь к базе данных

        public void AddBook(string название_книги, string автор, DateTime дата_публикации, string статус)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                using (var command = new SQLiteCommand(connection))
                {
                    command.CommandText = @"INSERT INTO books (Название_книги, Автор, Дата_публикации, Статус, Дата_добавления, Дата_изменения) 
                                            VALUES (@Название_книги, @Автор, @Дата_публикации, @Статус, @Дата_добавления, @Дата_изменения);";

                    command.Parameters.AddWithValue("@Название_книги", название_книги);
                    command.Parameters.AddWithValue("@Автор", автор);
                    command.Parameters.AddWithValue("@Дата_публикации", дата_публикации);
                    command.Parameters.AddWithValue("@Статус", статус);
                    command.Parameters.AddWithValue("@Дата_добавления", DateTime.Now); // Текущая дата
                    command.Parameters.AddWithValue("@Дата_изменения", DateTime.Now); // Текущая дата

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
