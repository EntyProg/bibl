﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Dashboard : UserControl
    {
        public Dashboard()
        {
            InitializeComponent();
            UpdateBookCount();
            UpdateIssuedBookCount();
        }

        private void UpdateBookCount()
        {
            string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;";

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM Books";
                    using (SQLiteCommand command = new SQLiteCommand(query, connection))
                    {
                        long bookCount = (long)command.ExecuteScalar();
                        label2.Text = $"{bookCount}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении количества книг: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateIssuedBookCount()
        {
            string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;";

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM BookIssues WHERE Дата_возврата IS NULL";
                    using (SQLiteCommand command = new SQLiteCommand(query, connection))
                    {
                        long issuedBookCount = (long)command.ExecuteScalar();
                        Vydannye_Books.Text = $"{issuedBookCount}";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении количества выданных книг: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void label2_Click(object sender, EventArgs e)
        {
            //  Здесь можно добавить функциональность для клика по label2, если нужно.
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            UpdateBookCount();
            UpdateIssuedBookCount();
        }

        private void Vydannye_Books_Click(object sender, EventArgs e)
        {

        }
    }
}
