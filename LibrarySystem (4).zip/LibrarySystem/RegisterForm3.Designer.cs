﻿namespace LibrarySystem
{
    partial class RegisterForm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Register_Show_Password = new CheckBox();
            Register_Btn = new Button();
            label5 = new Label();
            signInBtn = new Button();
            Register_Password = new TextBox();
            label4 = new Label();
            Register_Login = new TextBox();
            label3 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            label1 = new Label();
            Register_Email = new TextBox();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // Register_Show_Password
            // 
            Register_Show_Password.AutoSize = true;
            Register_Show_Password.Location = new Point(141, 358);
            Register_Show_Password.Name = "Register_Show_Password";
            Register_Show_Password.Size = new Size(150, 24);
            Register_Show_Password.TabIndex = 21;
            Register_Show_Password.Text = "Показать пароль";
            Register_Show_Password.UseVisualStyleBackColor = true;
            Register_Show_Password.CheckedChanged += Register_Show_Password_CheckedChanged;
            // 
            // Register_Btn
            // 
            Register_Btn.BackColor = Color.SeaGreen;
            Register_Btn.Cursor = Cursors.Hand;
            Register_Btn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            Register_Btn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            Register_Btn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            Register_Btn.ForeColor = Color.White;
            Register_Btn.Location = new Point(12, 403);
            Register_Btn.Name = "Register_Btn";
            Register_Btn.Size = new Size(279, 37);
            Register_Btn.TabIndex = 20;
            Register_Btn.Text = "ЗАРЕГИСТРИРОВАТЬСЯ";
            Register_Btn.UseVisualStyleBackColor = false;
            Register_Btn.Click += Register_Btn_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label5.Location = new Point(105, 453);
            label5.Name = "label5";
            label5.Size = new Size(96, 20);
            label5.TabIndex = 19;
            label5.Text = "Регистрация";
            // 
            // signInBtn
            // 
            signInBtn.BackColor = Color.SeaGreen;
            signInBtn.Cursor = Cursors.Hand;
            signInBtn.FlatAppearance.MouseDownBackColor = Color.LightGreen;
            signInBtn.FlatAppearance.MouseOverBackColor = Color.LightGreen;
            signInBtn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            signInBtn.ForeColor = Color.White;
            signInBtn.Location = new Point(12, 473);
            signInBtn.Name = "signInBtn";
            signInBtn.Size = new Size(279, 40);
            signInBtn.TabIndex = 18;
            signInBtn.Text = "ВХОД";
            signInBtn.UseVisualStyleBackColor = false;
            signInBtn.Click += signInBtn_Click;
            // 
            // Register_Password
            // 
            Register_Password.Location = new Point(12, 325);
            Register_Password.Name = "Register_Password";
            Register_Password.PasswordChar = '•';
            Register_Password.Size = new Size(279, 27);
            Register_Password.TabIndex = 17;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.Location = new Point(12, 301);
            label4.Name = "label4";
            label4.Size = new Size(65, 20);
            label4.TabIndex = 16;
            label4.Text = "Пароль:";
            // 
            // Register_Login
            // 
            Register_Login.Location = new Point(12, 271);
            Register_Login.Name = "Register_Login";
            Register_Login.Size = new Size(279, 27);
            Register_Login.TabIndex = 15;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.Location = new Point(12, 247);
            label3.Name = "label3";
            label3.Size = new Size(55, 20);
            label3.TabIndex = 14;
            label3.Text = "Логин:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(103, 153);
            label2.Name = "label2";
            label2.Size = new Size(109, 23);
            label2.TabIndex = 13;
            label2.Text = "Регистрация";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.books_library_study_icon_150963;
            pictureBox1.Location = new Point(105, 50);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.SeaGreen;
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(320, 35);
            panel1.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Arial Narrow", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ForeColor = Color.White;
            label1.Location = new Point(295, 7);
            label1.Name = "label1";
            label1.Size = new Size(17, 20);
            label1.TabIndex = 0;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // Register_Email
            // 
            Register_Email.Location = new Point(12, 217);
            Register_Email.Name = "Register_Email";
            Register_Email.Size = new Size(279, 27);
            Register_Email.TabIndex = 23;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label6.Location = new Point(12, 193);
            label6.Name = "label6";
            label6.Size = new Size(146, 20);
            label6.TabIndex = 22;
            label6.Text = "Электронная почта:";
            // 
            // RegisterForm3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(320, 525);
            Controls.Add(Register_Email);
            Controls.Add(label6);
            Controls.Add(Register_Show_Password);
            Controls.Add(Register_Btn);
            Controls.Add(label5);
            Controls.Add(signInBtn);
            Controls.Add(Register_Password);
            Controls.Add(label4);
            Controls.Add(Register_Login);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "RegisterForm3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "RegisterForm3";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox Register_Show_Password;
        private Button Register_Btn;
        private Label label5;
        private Button signInBtn;
        private TextBox Register_Password;
        private Label label4;
        private TextBox Register_Login;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label1;
        private TextBox Register_Email;
        private Label label6;
    }
}