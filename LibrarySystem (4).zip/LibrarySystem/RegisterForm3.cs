﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite; // Используем SQLite
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace LibrarySystem
{
    public partial class RegisterForm3 : Form
    {
        public RegisterForm3()
        {
            InitializeComponent();
        }

        private void signInBtn_Click(object sender, EventArgs e)
        {
            LoginForm2 loginForm = new LoginForm2();
            loginForm.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Register_Show_Password_CheckedChanged(object sender, EventArgs e)
        {
            Register_Password.PasswordChar = Register_Show_Password.Checked ? '\0' : '•';
        }

        private void Register_Btn_Click(object sender, EventArgs e)
        {
            string email = Register_Email.Text;
            string login = Register_Login.Text;
            string password = Register_Password.Text;
            DateTime registrationDate = DateTime.Now;

            //Строка подключения к базе данных SQLite.
            string connectionString = @"Data Source=E:\LibrSystem.db";

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    //Проверка на существование логина (для избежания дубликатов)
                    string checkLoginQuery = "SELECT COUNT(*) FROM users WHERE Login = @Login";
                    using (SQLiteCommand checkLoginCommand = new SQLiteCommand(checkLoginQuery, connection))
                    {
                        checkLoginCommand.Parameters.AddWithValue("@Login", login);
                        int count = Convert.ToInt32(checkLoginCommand.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Пользователь с таким логином уже существует!", "Ошибка регистрации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }


                    string insertQuery = "INSERT INTO users (E_Mail, Login, Password, Дата_регистрации) VALUES (@Email, @Login, @Password, @RegistrationDate)";
                    using (SQLiteCommand command = new SQLiteCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Login", login);
                        command.Parameters.AddWithValue("@Password", password); //Хранение паролей в незащищенном виде - НЕДОПУСТИМО в реальном приложении!  Используйте хеширование!
                        command.Parameters.AddWithValue("@RegistrationDate", registrationDate);
                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Регистрация прошла успешно!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // Возможно, после успешной регистрации нужно перейти на другую форму.
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при регистрации: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
