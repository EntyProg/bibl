﻿namespace LibrarySystem
{
    partial class MainForm_Readers
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label1 = new Label();
            Readers_Window = new DataGridView();
            panel2 = new Panel();
            Readers_AddBtn = new Button();
            Readers_Emaill = new TextBox();
            Readers_Phone_Number = new TextBox();
            Readers_Email = new Label();
            label8 = new Label();
            Readers_Number_Pasporta = new TextBox();
            Readers_Seria_Pasporta = new TextBox();
            Readers_Otchestvo = new TextBox();
            Readers_Name = new TextBox();
            Readers_Familia = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            Readers_UpgradeBtn = new Button();
            Readers_DeleteBtn = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Readers_Window).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonHighlight;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(Readers_Window);
            panel1.Location = new Point(14, 15);
            panel1.Name = "panel1";
            panel1.Size = new Size(854, 321);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(16, 14);
            label1.Name = "label1";
            label1.Size = new Size(88, 23);
            label1.TabIndex = 1;
            label1.Text = "Читатели";
            // 
            // Readers_Window
            // 
            Readers_Window.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Readers_Window.Location = new Point(16, 50);
            Readers_Window.Name = "Readers_Window";
            Readers_Window.RowHeadersWidth = 51;
            Readers_Window.Size = new Size(823, 244);
            Readers_Window.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gainsboro;
            panel2.Controls.Add(Readers_AddBtn);
            panel2.Controls.Add(Readers_Emaill);
            panel2.Controls.Add(Readers_Phone_Number);
            panel2.Controls.Add(Readers_Email);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(Readers_Number_Pasporta);
            panel2.Controls.Add(Readers_Seria_Pasporta);
            panel2.Controls.Add(Readers_Otchestvo);
            panel2.Controls.Add(Readers_Name);
            panel2.Controls.Add(Readers_Familia);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(Readers_UpgradeBtn);
            panel2.Controls.Add(Readers_DeleteBtn);
            panel2.Location = new Point(14, 342);
            panel2.Name = "panel2";
            panel2.Size = new Size(854, 209);
            panel2.TabIndex = 1;
            // 
            // Readers_AddBtn
            // 
            Readers_AddBtn.BackColor = Color.SeaGreen;
            Readers_AddBtn.FlatStyle = FlatStyle.Flat;
            Readers_AddBtn.ForeColor = Color.White;
            Readers_AddBtn.Location = new Point(254, 164);
            Readers_AddBtn.Name = "Readers_AddBtn";
            Readers_AddBtn.Size = new Size(99, 29);
            Readers_AddBtn.TabIndex = 59;
            Readers_AddBtn.Text = "ДОБАВИТЬ";
            Readers_AddBtn.UseVisualStyleBackColor = false;
            Readers_AddBtn.Click += Readers_AddBtn_Click_1;
            // 
            // Readers_Emaill
            // 
            Readers_Emaill.Location = new Point(695, 23);
            Readers_Emaill.Name = "Readers_Emaill";
            Readers_Emaill.Size = new Size(151, 27);
            Readers_Emaill.TabIndex = 58;
            // 
            // Readers_Phone_Number
            // 
            Readers_Phone_Number.Location = new Point(418, 107);
            Readers_Phone_Number.Name = "Readers_Phone_Number";
            Readers_Phone_Number.Size = new Size(159, 27);
            Readers_Phone_Number.TabIndex = 57;
            // 
            // Readers_Email
            // 
            Readers_Email.AutoSize = true;
            Readers_Email.Location = new Point(596, 7);
            Readers_Email.Name = "Readers_Email";
            Readers_Email.Size = new Size(103, 40);
            Readers_Email.TabIndex = 56;
            Readers_Email.Text = "Электронная \r\nпочта:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(282, 110);
            label8.Name = "label8";
            label8.Size = new Size(130, 20);
            label8.TabIndex = 55;
            label8.Text = "Номер телефона:";
            // 
            // Readers_Number_Pasporta
            // 
            Readers_Number_Pasporta.Location = new Point(418, 60);
            Readers_Number_Pasporta.Name = "Readers_Number_Pasporta";
            Readers_Number_Pasporta.Size = new Size(159, 27);
            Readers_Number_Pasporta.TabIndex = 48;
            // 
            // Readers_Seria_Pasporta
            // 
            Readers_Seria_Pasporta.Location = new Point(418, 20);
            Readers_Seria_Pasporta.Name = "Readers_Seria_Pasporta";
            Readers_Seria_Pasporta.Size = new Size(159, 27);
            Readers_Seria_Pasporta.TabIndex = 47;
            // 
            // Readers_Otchestvo
            // 
            Readers_Otchestvo.Location = new Point(117, 107);
            Readers_Otchestvo.Name = "Readers_Otchestvo";
            Readers_Otchestvo.Size = new Size(159, 27);
            Readers_Otchestvo.TabIndex = 46;
            // 
            // Readers_Name
            // 
            Readers_Name.Location = new Point(117, 64);
            Readers_Name.Name = "Readers_Name";
            Readers_Name.Size = new Size(159, 27);
            Readers_Name.TabIndex = 45;
            // 
            // Readers_Familia
            // 
            Readers_Familia.Location = new Point(117, 20);
            Readers_Familia.Name = "Readers_Familia";
            Readers_Familia.Size = new Size(159, 27);
            Readers_Familia.TabIndex = 44;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(287, 63);
            label7.Name = "label7";
            label7.Size = new Size(129, 20);
            label7.TabIndex = 43;
            label7.Text = "Номер паспорта:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(292, 23);
            label6.Name = "label6";
            label6.Size = new Size(124, 20);
            label6.TabIndex = 42;
            label6.Text = "Серия паспорта:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(41, 97);
            label5.Name = "label5";
            label5.Size = new Size(76, 40);
            label5.TabIndex = 41;
            label5.Text = "Отчество \r\nчитателя:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(41, 7);
            label4.Name = "label4";
            label4.Size = new Size(77, 40);
            label4.TabIndex = 40;
            label4.Text = "Фамилия \r\nчитателя:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(4, 63);
            label3.Name = "label3";
            label3.Size = new Size(107, 20);
            label3.TabIndex = 39;
            label3.Text = "Имя читателя:";
            // 
            // Readers_UpgradeBtn
            // 
            Readers_UpgradeBtn.BackColor = Color.SeaGreen;
            Readers_UpgradeBtn.FlatStyle = FlatStyle.Flat;
            Readers_UpgradeBtn.ForeColor = Color.White;
            Readers_UpgradeBtn.Location = new Point(389, 164);
            Readers_UpgradeBtn.Name = "Readers_UpgradeBtn";
            Readers_UpgradeBtn.Size = new Size(99, 29);
            Readers_UpgradeBtn.TabIndex = 25;
            Readers_UpgradeBtn.Text = "ИЗМЕНИТЬ";
            Readers_UpgradeBtn.UseVisualStyleBackColor = false;
            Readers_UpgradeBtn.Click += Readers_UpgradeBtn_Click;
            // 
            // Readers_DeleteBtn
            // 
            Readers_DeleteBtn.BackColor = Color.SeaGreen;
            Readers_DeleteBtn.FlatStyle = FlatStyle.Flat;
            Readers_DeleteBtn.ForeColor = Color.White;
            Readers_DeleteBtn.Location = new Point(515, 164);
            Readers_DeleteBtn.Name = "Readers_DeleteBtn";
            Readers_DeleteBtn.Size = new Size(99, 29);
            Readers_DeleteBtn.TabIndex = 24;
            Readers_DeleteBtn.Text = "УДАЛИТЬ";
            Readers_DeleteBtn.UseVisualStyleBackColor = false;
            Readers_DeleteBtn.Click += Readers_DeleteBtn_Click;
            // 
            // MainForm_Readers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "MainForm_Readers";
            Size = new Size(880, 565);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Readers_Window).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private DataGridView Readers_Window;
        private Label label1;
        private Panel panel2;
        private Button Readers_UpgradeBtn;
        private Button Readers_DeleteBtn;
        private TextBox Readers_Number_Pasporta;
        private TextBox Readers_Seria_Pasporta;
        private TextBox Readers_Otchestvo;
        private TextBox Readers_Name;
        private TextBox Readers_Familia;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private TextBox Readers_Emaill;
        private TextBox Readers_Phone_Number;
        private Label Readers_Email;
        private Label label8;
        private Button Readers_AddBtn;
    }
}
