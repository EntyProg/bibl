﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class MainForm_Readers : UserControl
    {
        private string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;";

        public MainForm_Readers()
        {
            InitializeComponent();
            LoadReaders();
            Readers_Window.SelectionChanged += Readers_Window_SelectionChanged;
            Readers_Window.ReadOnly = true; // Запрет на редактирование ячеек
        }

        private void Readers_Window_SelectionChanged(object sender, EventArgs e)
        {
            if (Readers_Window.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Readers_Window.SelectedRows[0];

                Readers_Familia.Text = selectedRow.Cells["Фамилия"].Value?.ToString() ?? "";
                Readers_Name.Text = selectedRow.Cells["Имя"].Value?.ToString() ?? "";
                Readers_Otchestvo.Text = selectedRow.Cells["Отчество"].Value?.ToString() ?? "";
                Readers_Seria_Pasporta.Text = selectedRow.Cells["Серия_паспорта"].Value?.ToString() ?? "";
                Readers_Number_Pasporta.Text = selectedRow.Cells["Номер_паспорта"].Value?.ToString() ?? "";
                Readers_Phone_Number.Text = selectedRow.Cells["Номер_телефона"].Value?.ToString() ?? "";
                Readers_Emaill.Text = selectedRow.Cells["Электронная_почта"].Value?.ToString() ?? "";
            }
            else
            {
                ClearFields();
            }
        }

        private void LoadReaders()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteCommand command = new SQLiteCommand("SELECT ID_Читателя, Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта, Номер_телефона, Электронная_почта FROM Readers", connection))
                {
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        Readers_Window.DataSource = dataTable;
                        Readers_Window.Columns["ID_Читателя"].Visible = false;
                    }
                }
            }
        }

        private void ClearFields()
        {
            Readers_Familia.Clear();
            Readers_Name.Clear();
            Readers_Otchestvo.Clear();
            Readers_Seria_Pasporta.Clear();
            Readers_Number_Pasporta.Clear();
            Readers_Phone_Number.Clear();
            Readers_Emaill.Clear();
        }

        private void Readers_AddBtn_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Readers_Familia.Text) ||
                string.IsNullOrWhiteSpace(Readers_Name.Text) ||
                string.IsNullOrWhiteSpace(Readers_Seria_Pasporta.Text) ||
                string.IsNullOrWhiteSpace(Readers_Number_Pasporta.Text) ||
                string.IsNullOrWhiteSpace(Readers_Phone_Number.Text) ||
                string.IsNullOrWhiteSpace(Readers_Emaill.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteCommand command = new SQLiteCommand("INSERT INTO Readers (Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта, Номер_телефона, Электронная_почта) VALUES (@Фамилия, @Имя, @Отчество, @Серия_паспорта, @Номер_паспорта, @Номер_телефона, @Электронная_почта)", connection))
                {
                    command.Parameters.AddWithValue("@Фамилия", Readers_Familia.Text);
                    command.Parameters.AddWithValue("@Имя", Readers_Name.Text);
                    command.Parameters.AddWithValue("@Отчество", Readers_Otchestvo.Text);
                    command.Parameters.AddWithValue("@Серия_паспорта", Readers_Seria_Pasporta.Text);
                    command.Parameters.AddWithValue("@Номер_паспорта", Readers_Number_Pasporta.Text);
                    command.Parameters.AddWithValue("@Номер_телефона", Readers_Phone_Number.Text);
                    command.Parameters.AddWithValue("@Электронная_почта", Readers_Emaill.Text);

                    try
                    {
                        command.ExecuteNonQuery();
                        LoadReaders();
                        ClearFields();
                        MessageBox.Show("Запись успешно добавлена!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при добавлении записи: {ex.Message}");
                    }
                }
            }
        }

        private void Readers_DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Readers_Window.SelectedRows.Count > 0)
            {
                int idToDelete = Convert.ToInt32(Readers_Window.SelectedRows[0].Cells["ID_Читателя"].Value);

                if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        using (SQLiteCommand command = new SQLiteCommand("DELETE FROM Readers WHERE ID_Читателя = @ID", connection))
                        {
                            command.Parameters.AddWithValue("@ID", idToDelete);
                            try
                            {
                                command.ExecuteNonQuery();
                                LoadReaders();
                                MessageBox.Show("Запись успешно удалена!");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Ошибка при удалении записи: {ex.Message}");
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления.");
            }
        }

        private void Readers_UpgradeBtn_Click(object sender, EventArgs e)
        {
            if (Readers_Window.SelectedRows.Count > 0)
            {
                int idToUpdate = Convert.ToInt32(Readers_Window.SelectedRows[0].Cells["ID_Читателя"].Value);

                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    using (SQLiteCommand command = new SQLiteCommand(@"UPDATE Readers SET 
                        Фамилия = @Фамилия, 
                        Имя = @Имя, 
                        Отчество = @Отчество, 
                        Серия_паспорта = @Серия_паспорта, 
                        Номер_паспорта = @Номер_паспорта, 
                        Номер_телефона = @Номер_телефона, 
                        Электронная_почта = @Электронная_почта 
                        WHERE ID_Читателя = @ID", connection))
                    {
                        command.Parameters.AddWithValue("@ID", idToUpdate);
                        command.Parameters.AddWithValue("@Фамилия", Readers_Familia.Text);
                        command.Parameters.AddWithValue("@Имя", Readers_Name.Text);
                        command.Parameters.AddWithValue("@Отчество", Readers_Otchestvo.Text);
                        command.Parameters.AddWithValue("@Серия_паспорта", Readers_Seria_Pasporta.Text);
                        command.Parameters.AddWithValue("@Номер_паспорта", Readers_Number_Pasporta.Text);
                        command.Parameters.AddWithValue("@Номер_телефона", Readers_Phone_Number.Text);
                        command.Parameters.AddWithValue("@Электронная_почта", Readers_Emaill.Text);

                        try
                        {
                            command.ExecuteNonQuery();
                            LoadReaders();
                            ClearFields();
                            MessageBox.Show("Запись успешно обновлена!");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Ошибка при обновлении записи: {ex.Message}");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для изменения.");
            }
        }
    }
}
