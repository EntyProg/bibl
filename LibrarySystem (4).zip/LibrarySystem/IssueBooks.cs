using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class IssueBooks : UserControl
    {
        private string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;";

        public IssueBooks()
        {
            InitializeComponent();
            LoadBooks();
            LoadReaders();
            
            // Привязываем обработчики событий
            button2.Click += Issue_Book_Click;
            Clear.Click += Clear_Click;
            Readers_IssueBooks.CellClick += Readers_IssueBooks_CellClick;
            All_Issue_Books.CellClick += All_Issue_Books_CellClick;
        }

        private void LoadBooks()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = @"SELECT ID as ID_Книги, Название_книги, Автор, Дата_публикации, 
                                  CASE 
                                     WHEN EXISTS (SELECT 1 FROM BookIssues WHERE ID_Книги = Books.ID AND Дата_возврата IS NULL)
                                     THEN 'Выдана'
                                     ELSE 'Не выдана'
                                  END AS Статус
                               FROM Books";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    All_Issue_Books.DataSource = dt;
                    All_Issue_Books.Columns["ID_Книги"].Visible = false;
                    All_Issue_Books.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
        }

        private void LoadReaders()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT ID_Читателя, Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта, Номер_телефона, Электронная_почта FROM Readers";
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    Readers_IssueBooks.DataSource = dt;
                    Readers_IssueBooks.Columns["ID_Читателя"].Visible = false;
                    Readers_IssueBooks.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
        }

        private void Readers_IssueBooks_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < Readers_IssueBooks.Rows.Count)
            {
                DataGridViewRow row = Readers_IssueBooks.Rows[e.RowIndex];
                Familia_Readers.Text = row.Cells["Фамилия"].Value?.ToString();
                Name_Readers.Text = row.Cells["Имя"].Value?.ToString();
                Otchestvo_Readers.Text = row.Cells["Отчество"].Value?.ToString();
                Seria_Readers.Text = row.Cells["Серия_паспорта"].Value?.ToString();
                Number_pasport_Readers.Text = row.Cells["Номер_паспорта"].Value?.ToString();
                Number_Phone_Readers.Text = row.Cells["Номер_телефона"].Value?.ToString();
                Email_Readers.Text = row.Cells["Электронная_почта"].Value?.ToString();
            }
        }

        private void All_Issue_Books_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < All_Issue_Books.Rows.Count)
            {
                DataGridViewRow row = All_Issue_Books.Rows[e.RowIndex];
                Name_Book_Readers.Text = row.Cells["Название_книги"].Value?.ToString();
                Author_Readers.Text = row.Cells["Автор"].Value?.ToString();

                if (DateTime.TryParse(row.Cells["Дата_публикации"].Value?.ToString(), out DateTime date))
                {
                    Data_Vydachi_Readers.Value = date;
                }
            }
        }

        private void Issue_Book_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Name_Book_Readers.Text) || string.IsNullOrEmpty(Seria_Readers.Text) || string.IsNullOrEmpty(Number_pasport_Readers.Text))
            {
                MessageBox.Show("Пожалуйста, выберите книгу и читателя", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        // Проверяем, не выдана ли уже книга
                        string checkQuery = @"SELECT COUNT(*) FROM BookIssues bi 
                                           JOIN Books b ON bi.ID_Книги = b.ID 
                                           WHERE b.Название_книги = @bookName 
                                           AND bi.Дата_возврата IS NULL";
                        
                        using (SQLiteCommand checkCommand = new SQLiteCommand(checkQuery, connection))
                        {
                            checkCommand.Parameters.AddWithValue("@bookName", Name_Book_Readers.Text);
                            int issuedCount = Convert.ToInt32(checkCommand.ExecuteScalar());
                            
                            if (issuedCount > 0)
                            {
                                MessageBox.Show("Эта книга уже выдана другому читателю", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        // Получаем ID книги
                        string bookIdQuery = "SELECT ID FROM Books WHERE Название_книги = @bookName";
                        int bookId;
                        using (SQLiteCommand bookCommand = new SQLiteCommand(bookIdQuery, connection))
                        {
                            bookCommand.Parameters.AddWithValue("@bookName", Name_Book_Readers.Text);
                            bookId = Convert.ToInt32(bookCommand.ExecuteScalar());
                        }

                        // Получаем ID читателя
                        string readerIdQuery = "SELECT ID_Читателя FROM Readers WHERE Серия_паспорта = @seria AND Номер_паспорта = @number";
                        int readerId;
                        using (SQLiteCommand readerCommand = new SQLiteCommand(readerIdQuery, connection))
                        {
                            readerCommand.Parameters.AddWithValue("@seria", Seria_Readers.Text);
                            readerCommand.Parameters.AddWithValue("@number", Number_pasport_Readers.Text);
                            readerId = Convert.ToInt32(readerCommand.ExecuteScalar());
                        }

                        // Добавляем запись о выдаче книги
                        string issueQuery = @"INSERT INTO BookIssues (ID_Книги, ID_Читателя, Дата_выдачи) 
                                           VALUES (@bookId, @readerId, @issueDate)";
                        
                        using (SQLiteCommand issueCommand = new SQLiteCommand(issueQuery, connection))
                        {
                            issueCommand.Parameters.AddWithValue("@bookId", bookId);
                            issueCommand.Parameters.AddWithValue("@readerId", readerId);
                            issueCommand.Parameters.AddWithValue("@issueDate", DateTime.Now);
                            issueCommand.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        MessageBox.Show("Книга успешно выдана читателю", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        // Обновляем списки
                        LoadBooks();
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка при выдаче книги: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            Name_Book_Readers.Text = "";
            Author_Readers.Text = "";
            Familia_Readers.Text = "";
            Name_Readers.Text = "";
            Otchestvo_Readers.Text = "";
            Seria_Readers.Text = "";
            Number_pasport_Readers.Text = "";
            Number_Phone_Readers.Text = "";
            Email_Readers.Text = "";
            Data_Vydachi_Readers.Value = DateTime.Now;
        }
    }
}
