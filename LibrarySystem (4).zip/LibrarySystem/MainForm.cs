﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Вы действительно хотите выйти?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (check == DialogResult.Yes)
            {
                LoginForm2 loginForm2 = new LoginForm2();
                loginForm2.Show();
                this.Hide();
            }
        }

        private void dashboard_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = true;
            addBooks1.Visible = false;
            returnBooks1.Visible = false;
            issueBooks1.Visible = false;
            mainForm_Readers1.Visible = false;
            library1.Visible = false;
            jurnalSobytiy1.Visible = false;
        }

        private void add_book_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = true;
            returnBooks1.Visible = false;
            issueBooks1.Visible = false;
            mainForm_Readers1.Visible = false;
            library1.Visible = false;
            jurnalSobytiy1.Visible = false;
        }

        private void Issue_book_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = false;
            returnBooks1.Visible = false;
            issueBooks1.Visible = true;
            mainForm_Readers1.Visible = false;
            library1.Visible = false;
            jurnalSobytiy1.Visible = false;
        }

        private void Return_book_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = false;
            returnBooks1.Visible = true;
            issueBooks1.Visible = false;
            mainForm_Readers1.Visible = false;
            library1.Visible = false;
            jurnalSobytiy1.Visible = false;
        }

        private void ReadersBtn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = false;
            returnBooks1.Visible = false;
            issueBooks1.Visible = false;
            mainForm_Readers1.Visible = true;
            library1.Visible = false;
            jurnalSobytiy1.Visible = false;
        }

        private void library_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = false;
            returnBooks1.Visible = false;
            issueBooks1.Visible = false;
            mainForm_Readers1.Visible = false;
            library1.Visible = true;
            jurnalSobytiy1.Visible = false;
        }

        private void Jurnal_SobytiyBtn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = false;
            returnBooks1.Visible = false;
            issueBooks1.Visible = false;
            mainForm_Readers1.Visible = false;
            library1.Visible = false;
            jurnalSobytiy1.Visible = true;
        }
    }
}
