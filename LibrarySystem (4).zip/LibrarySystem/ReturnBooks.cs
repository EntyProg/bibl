using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class ReturnBooks : UserControl
    {
        private string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;";

        public ReturnBooks()
        {
            InitializeComponent();
            LoadIssuedBooks();
            
            // Привязываем обработчики событий
            button1.Click += ReturnBook_Click;
            button2.Click += ClearFields_Click;
            dataGridView1.CellClick += IssuedBooksGrid_CellClick;
        }

        private void LoadIssuedBooks()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = @"SELECT 
                                bi.ID_Выдачи as ID_Выдачи,
                                b.Название_книги,
                                b.Автор,
                                r.Фамилия,
                                r.Имя,
                                r.Отчество,
                                bi.Дата_выдачи
                               FROM BookIssues bi
                               JOIN Books b ON bi.ID_Книги = b.ID
                               JOIN Readers r ON bi.ID_Читателя = r.ID_Читателя
                               WHERE bi.Дата_возврата IS NULL";

                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(query, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns["ID_Выдачи"].Visible = false;
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
        }

        private void IssuedBooksGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                Name_Book_Readers.Text = row.Cells["Название_книги"].Value?.ToString();
                Author_Readers.Text = row.Cells["Автор"].Value?.ToString();
                string readerFullName = $"{row.Cells["Фамилия"].Value} {row.Cells["Имя"].Value} {row.Cells["Отчество"].Value}";
                Familia_Readers.Text = row.Cells["Фамилия"].Value?.ToString();
                Name_Readers.Text = row.Cells["Имя"].Value?.ToString();
                Otchestvo_Readers.Text = row.Cells["Отчество"].Value?.ToString();
                
                if (DateTime.TryParse(row.Cells["Дата_выдачи"].Value?.ToString(), out DateTime issueDate))
                {
                    Data_Vydachi_Readers.Value = issueDate;
                }
                Date_vozvrata_.Value = DateTime.Now;
            }
        }

        private void ReturnBook_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите книгу для возврата", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int issueId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID_Выдачи"].Value);

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        string returnQuery = "UPDATE BookIssues SET Дата_возврата = @returnDate WHERE ID_Выдачи = @issueId";
                        using (SQLiteCommand returnCommand = new SQLiteCommand(returnQuery, connection))
                        {
                            returnCommand.Parameters.AddWithValue("@returnDate", Date_vozvrata_.Value);
                            returnCommand.Parameters.AddWithValue("@issueId", issueId);
                            returnCommand.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        MessageBox.Show("Книга успешно возвращена", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        // Обновляем список выданных книг
                        LoadIssuedBooks();
                        ClearFields();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка при возврате книги: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void ClearFields_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            Name_Book_Readers.Text = "";
            Author_Readers.Text = "";
            Familia_Readers.Text = "";
            Name_Readers.Text = "";
            Otchestvo_Readers.Text = "";
            Data_Vydachi_Readers.Value = DateTime.Now;
            Date_vozvrata_.Value = DateTime.Now;
        }
    }
}
