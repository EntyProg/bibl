﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Library : UserControl
    {
        private string connectionString = "Data Source=E:\\LibrSystem.db;Version=3;";

        public Library()
        {
            InitializeComponent();
            LoadLibrarians();
            Library_Window.SelectionChanged += Library_Window_SelectionChanged;
        }

        private void LoadLibrarians()
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteCommand command = new SQLiteCommand("SELECT Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта, Номер_телефона, Электронная_почта FROM Library", connection))
                {
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);
                        Library_Window.DataSource = dataTable;
                    }
                }
            }
        }

        private void Library_AddBtn_Click(object sender, EventArgs e)
        {
            // Проверка на пустые поля
            if (string.IsNullOrEmpty(Library_Familia.Text) || string.IsNullOrEmpty(Library_Name.Text) ||
                string.IsNullOrEmpty(Library_Seria.Text) ||
                string.IsNullOrEmpty(Library_Number.Text))
            {
                MessageBox.Show("Пожалуйста, заполните обязательные поля (Фамилия, Имя, Серия паспорта, Номер паспорта).");
                return;
            }

            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteCommand command = new SQLiteCommand("INSERT INTO Library (Фамилия, Имя, Отчество, Серия_паспорта, Номер_паспорта, Номер_телефона, Электронная_почта) VALUES (@Familia, @Name, @Otchestvo, @Seria, @Number, @NumberPhone, @Email)", connection))
                {
                    command.Parameters.AddWithValue("@Familia", Library_Familia.Text);
                    command.Parameters.AddWithValue("@Name", Library_Name.Text);
                    command.Parameters.AddWithValue("@Otchestvo", Library_Otchestvo.Text);
                    command.Parameters.AddWithValue("@Seria", Library_Seria.Text);
                    command.Parameters.AddWithValue("@Number", Library_Number.Text);
                    command.Parameters.AddWithValue("@NumberPhone", Library_Number_Phone.Text);
                    command.Parameters.AddWithValue("@Email", Library_Email.Text);

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Библиотекарь добавлен!");
                        LoadLibrarians();
                        ClearFields();
                    }
                    catch (SQLiteException ex) when (ex.ErrorCode == 19) //UNIQUE constraint failed
                    {
                        MessageBox.Show("Ошибка: Номер паспорта или электронная почта уже существует.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при добавлении библиотекаря: " + ex.Message);
                    }
                }
            }
        }

        private void ClearFields()
        {
            Library_Familia.Text = "";
            Library_Name.Text = "";
            Library_Otchestvo.Text = "";
            Library_Seria.Text = "";
            Library_Number.Text = "";
            Library_Number_Phone.Text = "";
            Library_Email.Text = "";
        }

        private void Library_DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Library_Window.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку для удаления.");
                return;
            }

            // Find ID -  This requires a bit of a change since ID is not directly visible
            string passportNumber = Library_Window.SelectedRows[0].Cells["Номер_паспорта"].Value.ToString();
            int id = GetLibrarianId(passportNumber); // Function added below

            if (id == -1)
            {
                MessageBox.Show("Невозможно определить запись для удаления.");
                return;
            }

            if (MessageBox.Show("Вы уверены, что хотите удалить запись?", "Подтверждение удаления", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    using (SQLiteCommand command = new SQLiteCommand("DELETE FROM Library WHERE ID_Библиотекаря = @ID", connection))
                    {
                        command.Parameters.AddWithValue("@ID", id);

                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("Запись удалена!");
                            LoadLibrarians();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка при удалении записи: " + ex.Message);
                        }
                    }
                }
            }
        }


        private void Library_UpdateBtn_Click(object sender, EventArgs e)
        {
            if (Library_Window.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку для изменения.");
                return;
            }

            // Find ID -  This requires a bit of a change since ID is not directly visible
            string passportNumber = Library_Window.SelectedRows[0].Cells["Номер_паспорта"].Value.ToString();
            int id = GetLibrarianId(passportNumber); // Function added below

            if (id == -1)
            {
                MessageBox.Show("Невозможно определить запись для изменения.");
                return;
            }


            // Проверка на пустые поля (обязательные поля)
            if (string.IsNullOrEmpty(Library_Familia.Text) || string.IsNullOrEmpty(Library_Name.Text) ||
                string.IsNullOrEmpty(Library_Seria.Text) ||
                string.IsNullOrEmpty(Library_Number.Text))
            {
                MessageBox.Show("Пожалуйста, заполните обязательные поля (Фамилия, Имя, Серия паспорта, Номер паспорта).");
                return;
            }

            if (MessageBox.Show("Вы уверены, что хотите изменить запись?", "Подтверждение изменения", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                using (SQLiteConnection connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    using (SQLiteCommand command = new SQLiteCommand(@"UPDATE Library 
                                                                        SET Фамилия = @Familia, Имя = @Name, Отчество = @Otchestvo, 
                                                                            Серия_паспорта = @Seria, Номер_паспорта = @Number, 
                                                                            Номер_телефона = @NumberPhone, Электронная_почта = @Email
                                                                        WHERE ID_Библиотекаря = @ID", connection))
                    {
                        command.Parameters.AddWithValue("@Familia", Library_Familia.Text);
                        command.Parameters.AddWithValue("@Name", Library_Name.Text);
                        command.Parameters.AddWithValue("@Otchestvo", Library_Otchestvo.Text);
                        command.Parameters.AddWithValue("@Seria", Library_Seria.Text);
                        command.Parameters.AddWithValue("@Number", Library_Number.Text);
                        command.Parameters.AddWithValue("@NumberPhone", Library_Number_Phone.Text);
                        command.Parameters.AddWithValue("@Email", Library_Email.Text);
                        command.Parameters.AddWithValue("@ID", id);

                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("Запись изменена!");
                            LoadLibrarians();
                            ClearFields();
                        }
                        catch (SQLiteException ex) when (ex.ErrorCode == 19) //UNIQUE constraint failed
                        {
                            MessageBox.Show("Ошибка: Номер паспорта или электронная почта уже существует.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка при изменении записи: " + ex.Message);
                        }
                    }
                }
            }
        }

        private void Library_Window_SelectionChanged(object sender, EventArgs e)
        {
            if (Library_Window.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Library_Window.SelectedRows[0];

                Library_Familia.Text = selectedRow.Cells["Фамилия"].Value?.ToString() ?? "";
                Library_Name.Text = selectedRow.Cells["Имя"].Value?.ToString() ?? "";
                Library_Otchestvo.Text = selectedRow.Cells["Отчество"].Value?.ToString() ?? "";
                Library_Seria.Text = selectedRow.Cells["Серия_паспорта"].Value?.ToString() ?? "";
                Library_Number.Text = selectedRow.Cells["Номер_паспорта"].Value?.ToString() ?? "";
                Library_Number_Phone.Text = selectedRow.Cells["Номер_телефона"].Value?.ToString() ?? "";
                Library_Email.Text = selectedRow.Cells["Электронная_почта"].Value?.ToString() ?? "";
            }
            else
            {
                ClearFields();
            }
        }

        // Helper function to get the ID based on passport number
        private int GetLibrarianId(string passportNumber)
        {
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (SQLiteCommand command = new SQLiteCommand("SELECT ID_Библиотекаря FROM Library WHERE Номер_паспорта = @PassportNumber", connection))
                {
                    command.Parameters.AddWithValue("@PassportNumber", passportNumber);
                    using (SQLiteDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return Convert.ToInt32(reader["ID_Библиотекаря"]);
                        }
                    }
                }
            }
            return -1; // Return -1 if not found
        }
    }
}
