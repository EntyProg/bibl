namespace LibrarySystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 10;

            if(panel2.Width >= 500)
            {
                timer1.Stop();

                LoginForm2 LForm = new LoginForm2();
                LForm.Show();
                this.Hide();
            }
        }
    }
}
