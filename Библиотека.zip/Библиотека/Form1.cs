namespace Библиотека
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (passwordTextBox.PasswordChar == '•')
            {
                // Показывает введенный пароль
                passwordTextBox.PasswordChar = '\0'; // '\0' - это null-символ, который не отображается
            }
            else
            {
                // Скрывает пароль
                passwordTextBox.PasswordChar = '•';
            }
        }

        private void button1_Click(object sender, EventArgs e) // Кнопка входа (авторизация)
        {
            string username = loginBox1.Text;
            string password = passwordTextBox.Text;

            // Проверка логина и пароля
            if (username == "admin" && password == "admin")
            {
                // Открытие окна администратора
                Администратор adminForm = new Администратор();
                adminForm.Show();
            }
            else if (username == "user" && password == "user")
            {
                // Открытие окна пользователя
                Пользователь userForm = new Пользователь();
                userForm.Show();
            }
            else if (username == "lib" && password == "lib")
            {
                // Открытие окна библиотекаря
                Библиотекарь librarianForm = new Библиотекарь();
                librarianForm.Show();
            }
            else
            {
                // Ошибка авторизации - имитация всплывающего окна на сайте
                MessageBox.Show("Неверный логин или пароль!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // Проверяем, нажата ли клавиша Enter
            if (e.KeyCode == Keys.Enter)
            {
                // Вызываем обработчик события Click для кнопки
                button1_Click(null, null);
            }
        }
    }
}
