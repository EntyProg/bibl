﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Библиотека
{
    public partial class Библиотекарь : Form
    {
        public Библиотекарь()
        {
            InitializeComponent();
        }

        private void Библиотекарь_Load(object sender, EventArgs e)
        {

        }
    }
}
