﻿namespace Библиотека
{
    partial class Администратор
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Администратор));
            tabControl1 = new TabControl();
            Читатели = new TabPage();
            label22 = new Label();
            textBox27 = new TextBox();
            label21 = new Label();
            textBox26 = new TextBox();
            label20 = new Label();
            label19 = new Label();
            textBox25 = new TextBox();
            textBox23 = new TextBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox7 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            dataGridView1 = new DataGridView();
            Книги = new TabPage();
            button4 = new Button();
            label26 = new Label();
            button5 = new Button();
            button9 = new Button();
            textBox29 = new TextBox();
            label25 = new Label();
            textBox28 = new TextBox();
            label24 = new Label();
            textBox9 = new TextBox();
            label23 = new Label();
            textBox8 = new TextBox();
            label9 = new Label();
            label12 = new Label();
            label10 = new Label();
            label8 = new Label();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox11 = new TextBox();
            dataGridView2 = new DataGridView();
            Библиотекарь = new TabPage();
            button6 = new Button();
            label28 = new Label();
            button7 = new Button();
            label29 = new Label();
            button8 = new Button();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            label11 = new Label();
            textBox10 = new TextBox();
            label27 = new Label();
            textBox12 = new TextBox();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            textBox24 = new TextBox();
            textBox22 = new TextBox();
            textBox21 = new TextBox();
            textBox20 = new TextBox();
            textBox19 = new TextBox();
            textBox18 = new TextBox();
            dataGridView3 = new DataGridView();
            Выдача_книг = new TabPage();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            label36 = new Label();
            textBox35 = new TextBox();
            label30 = new Label();
            label31 = new Label();
            textBox17 = new TextBox();
            textBox30 = new TextBox();
            label32 = new Label();
            label33 = new Label();
            label34 = new Label();
            label35 = new Label();
            textBox31 = new TextBox();
            textBox32 = new TextBox();
            textBox33 = new TextBox();
            textBox34 = new TextBox();
            dataGridView4 = new DataGridView();
            Журнал_событий = new TabPage();
            button13 = new Button();
            dataGridView5 = new DataGridView();
            tabControl1.SuspendLayout();
            Читатели.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            Книги.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            Библиотекарь.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            Выдача_книг.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            Журнал_событий.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Читатели);
            tabControl1.Controls.Add(Книги);
            tabControl1.Controls.Add(Библиотекарь);
            tabControl1.Controls.Add(Выдача_книг);
            tabControl1.Controls.Add(Журнал_событий);
            tabControl1.Location = new Point(3, 1);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1178, 685);
            tabControl1.TabIndex = 0;
            // 
            // Читатели
            // 
            Читатели.Controls.Add(label22);
            Читатели.Controls.Add(textBox27);
            Читатели.Controls.Add(label21);
            Читатели.Controls.Add(textBox26);
            Читатели.Controls.Add(label20);
            Читатели.Controls.Add(label19);
            Читатели.Controls.Add(textBox25);
            Читатели.Controls.Add(textBox23);
            Читатели.Controls.Add(button3);
            Читатели.Controls.Add(button2);
            Читатели.Controls.Add(button1);
            Читатели.Controls.Add(label7);
            Читатели.Controls.Add(label6);
            Читатели.Controls.Add(label5);
            Читатели.Controls.Add(label4);
            Читатели.Controls.Add(label3);
            Читатели.Controls.Add(label2);
            Читатели.Controls.Add(label1);
            Читатели.Controls.Add(textBox7);
            Читатели.Controls.Add(textBox5);
            Читатели.Controls.Add(textBox6);
            Читатели.Controls.Add(textBox3);
            Читатели.Controls.Add(textBox4);
            Читатели.Controls.Add(textBox2);
            Читатели.Controls.Add(textBox1);
            Читатели.Controls.Add(dataGridView1);
            Читатели.Location = new Point(4, 29);
            Читатели.Name = "Читатели";
            Читатели.Padding = new Padding(3);
            Читатели.Size = new Size(1170, 652);
            Читатели.TabIndex = 0;
            Читатели.Text = "Читатели";
            Читатели.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(440, 461);
            label22.Name = "label22";
            label22.Size = new Size(51, 20);
            label22.TabIndex = 25;
            label22.Text = "Адрес";
            // 
            // textBox27
            // 
            textBox27.Location = new Point(440, 484);
            textBox27.Name = "textBox27";
            textBox27.Size = new Size(151, 27);
            textBox27.TabIndex = 24;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(283, 461);
            label21.Name = "label21";
            label21.Size = new Size(116, 20);
            label21.TabIndex = 23;
            label21.Text = "Дата рождения";
            // 
            // textBox26
            // 
            textBox26.Location = new Point(283, 484);
            textBox26.Name = "textBox26";
            textBox26.Size = new Size(151, 27);
            textBox26.TabIndex = 22;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(754, 461);
            label20.Name = "label20";
            label20.Size = new Size(117, 20);
            label20.TabIndex = 21;
            label20.Text = "Задолженность";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(597, 461);
            label19.Name = "label19";
            label19.Size = new Size(134, 20);
            label19.TabIndex = 20;
            label19.Text = "Дата регистрации";
            // 
            // textBox25
            // 
            textBox25.Location = new Point(754, 484);
            textBox25.Name = "textBox25";
            textBox25.Size = new Size(151, 27);
            textBox25.TabIndex = 19;
            // 
            // textBox23
            // 
            textBox23.Location = new Point(597, 484);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(151, 27);
            textBox23.TabIndex = 18;
            // 
            // button3
            // 
            button3.Location = new Point(684, 531);
            button3.Name = "button3";
            button3.Size = new Size(137, 31);
            button3.TabIndex = 17;
            button3.Text = "Удалить";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(527, 531);
            button2.Name = "button2";
            button2.Size = new Size(137, 31);
            button2.TabIndex = 16;
            button2.Text = "Изменить";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(370, 531);
            button1.Name = "button1";
            button1.Size = new Size(137, 31);
            button1.TabIndex = 15;
            button1.Text = "Добавить";
            button1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(984, 399);
            label7.Name = "label7";
            label7.Size = new Size(69, 20);
            label7.TabIndex = 14;
            label7.Text = "Телефон";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(827, 399);
            label6.Name = "label6";
            label6.Size = new Size(57, 20);
            label6.TabIndex = 13;
            label6.Text = "Номер";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(670, 399);
            label5.Name = "label5";
            label5.Size = new Size(52, 20);
            label5.TabIndex = 12;
            label5.Text = "Серия";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(513, 399);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 11;
            label4.Text = "Отчество";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(356, 399);
            label3.Name = "label3";
            label3.Size = new Size(39, 20);
            label3.TabIndex = 10;
            label3.Text = "Имя";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(199, 399);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 9;
            label2.Text = "Фамилия";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(42, 399);
            label1.Name = "label1";
            label1.Size = new Size(91, 20);
            label1.TabIndex = 8;
            label1.Text = "ID Читателя";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(984, 422);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(151, 27);
            textBox7.TabIndex = 7;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(827, 422);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(151, 27);
            textBox5.TabIndex = 6;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(670, 422);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(151, 27);
            textBox6.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(513, 422);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(151, 27);
            textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(356, 422);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(151, 27);
            textBox4.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(199, 422);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(151, 27);
            textBox2.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(42, 422);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(151, 27);
            textBox1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(2, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1165, 357);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Книги
            // 
            Книги.Controls.Add(button4);
            Книги.Controls.Add(label26);
            Книги.Controls.Add(button5);
            Книги.Controls.Add(button9);
            Книги.Controls.Add(textBox29);
            Книги.Controls.Add(label25);
            Книги.Controls.Add(textBox28);
            Книги.Controls.Add(label24);
            Книги.Controls.Add(textBox9);
            Книги.Controls.Add(label23);
            Книги.Controls.Add(textBox8);
            Книги.Controls.Add(label9);
            Книги.Controls.Add(label12);
            Книги.Controls.Add(label10);
            Книги.Controls.Add(label8);
            Книги.Controls.Add(textBox13);
            Книги.Controls.Add(textBox14);
            Книги.Controls.Add(textBox11);
            Книги.Controls.Add(dataGridView2);
            Книги.Location = new Point(4, 29);
            Книги.Name = "Книги";
            Книги.Padding = new Padding(3);
            Книги.Size = new Size(1170, 652);
            Книги.TabIndex = 1;
            Книги.Text = "Книги";
            Книги.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(668, 519);
            button4.Name = "button4";
            button4.Size = new Size(137, 31);
            button4.TabIndex = 20;
            button4.Text = "Удалить";
            button4.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(713, 445);
            label26.Name = "label26";
            label26.Size = new Size(262, 20);
            label26.TabIndex = 27;
            label26.Text = "Количество доступных экземпляров";
            // 
            // button5
            // 
            button5.Location = new Point(511, 519);
            button5.Name = "button5";
            button5.Size = new Size(137, 31);
            button5.TabIndex = 19;
            button5.Text = "Изменить";
            button5.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(354, 519);
            button9.Name = "button9";
            button9.Size = new Size(137, 31);
            button9.TabIndex = 18;
            button9.Text = "Добавить";
            button9.UseVisualStyleBackColor = true;
            // 
            // textBox29
            // 
            textBox29.Location = new Point(713, 467);
            textBox29.Name = "textBox29";
            textBox29.Size = new Size(263, 27);
            textBox29.TabIndex = 26;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(444, 444);
            label25.Name = "label25";
            label25.Size = new Size(185, 20);
            label25.TabIndex = 25;
            label25.Text = "Количество экземпляров";
            // 
            // textBox28
            // 
            textBox28.Location = new Point(444, 466);
            textBox28.Name = "textBox28";
            textBox28.Size = new Size(263, 27);
            textBox28.TabIndex = 24;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(175, 443);
            label24.Name = "label24";
            label24.Size = new Size(95, 20);
            label24.TabIndex = 23;
            label24.Text = "Год издания";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(175, 465);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(263, 27);
            textBox9.TabIndex = 22;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(840, 375);
            label23.Name = "label23";
            label23.Size = new Size(48, 20);
            label23.TabIndex = 21;
            label23.Text = "Жанр";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(840, 397);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(263, 27);
            textBox8.TabIndex = 20;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(571, 374);
            label9.Name = "label9";
            label9.Size = new Size(77, 20);
            label9.TabIndex = 19;
            label9.Text = "Название";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(33, 374);
            label12.Name = "label12";
            label12.Size = new Size(70, 20);
            label12.TabIndex = 18;
            label12.Text = "ID Книги";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(302, 375);
            label10.Name = "label10";
            label10.Size = new Size(51, 20);
            label10.TabIndex = 16;
            label10.Text = "Автор";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 375);
            label8.Name = "label8";
            label8.Size = new Size(0, 20);
            label8.TabIndex = 14;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(571, 397);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(263, 27);
            textBox13.TabIndex = 7;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(33, 397);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(263, 27);
            textBox14.TabIndex = 6;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(302, 397);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(263, 27);
            textBox11.TabIndex = 4;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(2, 3);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(1165, 357);
            dataGridView2.TabIndex = 1;
            // 
            // Библиотекарь
            // 
            Библиотекарь.Controls.Add(button6);
            Библиотекарь.Controls.Add(label28);
            Библиотекарь.Controls.Add(button7);
            Библиотекарь.Controls.Add(label29);
            Библиотекарь.Controls.Add(button8);
            Библиотекарь.Controls.Add(textBox15);
            Библиотекарь.Controls.Add(textBox16);
            Библиотекарь.Controls.Add(label11);
            Библиотекарь.Controls.Add(textBox10);
            Библиотекарь.Controls.Add(label27);
            Библиотекарь.Controls.Add(textBox12);
            Библиотекарь.Controls.Add(label18);
            Библиотекарь.Controls.Add(label17);
            Библиотекарь.Controls.Add(label16);
            Библиотекарь.Controls.Add(label15);
            Библиотекарь.Controls.Add(label14);
            Библиотекарь.Controls.Add(label13);
            Библиотекарь.Controls.Add(textBox24);
            Библиотекарь.Controls.Add(textBox22);
            Библиотекарь.Controls.Add(textBox21);
            Библиотекарь.Controls.Add(textBox20);
            Библиотекарь.Controls.Add(textBox19);
            Библиотекарь.Controls.Add(textBox18);
            Библиотекарь.Controls.Add(dataGridView3);
            Библиотекарь.Location = new Point(4, 29);
            Библиотекарь.Name = "Библиотекарь";
            Библиотекарь.Size = new Size(1170, 652);
            Библиотекарь.TabIndex = 2;
            Библиотекарь.Text = "Библиотекарь";
            Библиотекарь.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(674, 531);
            button6.Name = "button6";
            button6.Size = new Size(137, 31);
            button6.TabIndex = 20;
            button6.Text = "Удалить";
            button6.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(949, 396);
            label28.Name = "label28";
            label28.Size = new Size(57, 20);
            label28.TabIndex = 33;
            label28.Text = "Номер";
            // 
            // button7
            // 
            button7.Location = new Point(517, 531);
            button7.Name = "button7";
            button7.Size = new Size(137, 31);
            button7.TabIndex = 19;
            button7.Text = "Изменить";
            button7.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(779, 396);
            label29.Name = "label29";
            label29.Size = new Size(52, 20);
            label29.TabIndex = 32;
            label29.Text = "Серия";
            // 
            // button8
            // 
            button8.Location = new Point(360, 531);
            button8.Name = "button8";
            button8.Size = new Size(137, 31);
            button8.TabIndex = 18;
            button8.Text = "Добавить";
            button8.UseVisualStyleBackColor = true;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(949, 419);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(151, 27);
            textBox15.TabIndex = 31;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(779, 419);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(151, 27);
            textBox16.TabIndex = 30;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(446, 461);
            label11.Name = "label11";
            label11.Size = new Size(51, 20);
            label11.TabIndex = 29;
            label11.Text = "Адрес";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(446, 484);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(151, 27);
            textBox10.TabIndex = 28;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(279, 461);
            label27.Name = "label27";
            label27.Size = new Size(116, 20);
            label27.TabIndex = 27;
            label27.Text = "Дата рождения";
            // 
            // textBox12
            // 
            textBox12.Location = new Point(279, 484);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(151, 27);
            textBox12.TabIndex = 26;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(778, 461);
            label18.Name = "label18";
            label18.Size = new Size(52, 20);
            label18.TabIndex = 20;
            label18.Text = "E-mail";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(613, 461);
            label17.Name = "label17";
            label17.Size = new Size(57, 20);
            label17.TabIndex = 19;
            label17.Text = "Номер";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(611, 396);
            label16.Name = "label16";
            label16.Size = new Size(72, 20);
            label16.TabIndex = 18;
            label16.Text = "Отчество";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(446, 396);
            label15.Name = "label15";
            label15.Size = new Size(39, 20);
            label15.TabIndex = 17;
            label15.Text = "Имя";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(280, 396);
            label14.Name = "label14";
            label14.Size = new Size(73, 20);
            label14.TabIndex = 16;
            label14.Text = "Фамилия";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(113, 396);
            label13.Name = "label13";
            label13.Size = new Size(127, 20);
            label13.TabIndex = 15;
            label13.Text = "ID Библиотекаря";
            // 
            // textBox24
            // 
            textBox24.Location = new Point(778, 484);
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(150, 27);
            textBox24.TabIndex = 8;
            // 
            // textBox22
            // 
            textBox22.Location = new Point(613, 484);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(150, 27);
            textBox22.TabIndex = 7;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(611, 419);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(150, 27);
            textBox21.TabIndex = 6;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(446, 419);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(150, 27);
            textBox20.TabIndex = 5;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(280, 419);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(150, 27);
            textBox19.TabIndex = 4;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(113, 419);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(150, 27);
            textBox18.TabIndex = 3;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(2, 3);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(1165, 357);
            dataGridView3.TabIndex = 2;
            // 
            // Выдача_книг
            // 
            Выдача_книг.Controls.Add(button10);
            Выдача_книг.Controls.Add(button11);
            Выдача_книг.Controls.Add(button12);
            Выдача_книг.Controls.Add(label36);
            Выдача_книг.Controls.Add(textBox35);
            Выдача_книг.Controls.Add(label30);
            Выдача_книг.Controls.Add(label31);
            Выдача_книг.Controls.Add(textBox17);
            Выдача_книг.Controls.Add(textBox30);
            Выдача_книг.Controls.Add(label32);
            Выдача_книг.Controls.Add(label33);
            Выдача_книг.Controls.Add(label34);
            Выдача_книг.Controls.Add(label35);
            Выдача_книг.Controls.Add(textBox31);
            Выдача_книг.Controls.Add(textBox32);
            Выдача_книг.Controls.Add(textBox33);
            Выдача_книг.Controls.Add(textBox34);
            Выдача_книг.Controls.Add(dataGridView4);
            Выдача_книг.Location = new Point(4, 29);
            Выдача_книг.Name = "Выдача_книг";
            Выдача_книг.Size = new Size(1170, 652);
            Выдача_книг.TabIndex = 5;
            Выдача_книг.Text = "Выдача книг";
            Выдача_книг.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(687, 531);
            button10.Name = "button10";
            button10.Size = new Size(137, 31);
            button10.TabIndex = 50;
            button10.Text = "Удалить";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(530, 531);
            button11.Name = "button11";
            button11.Size = new Size(137, 31);
            button11.TabIndex = 49;
            button11.Text = "Изменить";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(373, 531);
            button12.Name = "button12";
            button12.Size = new Size(137, 31);
            button12.TabIndex = 48;
            button12.Text = "Добавить";
            button12.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(215, 451);
            label36.Name = "label36";
            label36.Size = new Size(97, 20);
            label36.TabIndex = 47;
            label36.Text = "Дата выдачи";
            // 
            // textBox35
            // 
            textBox35.Location = new Point(215, 474);
            textBox35.Name = "textBox35";
            textBox35.Size = new Size(236, 27);
            textBox35.TabIndex = 46;
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(476, 451);
            label30.Name = "label30";
            label30.Size = new Size(108, 20);
            label30.TabIndex = 45;
            label30.Text = "Дата возврата";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(736, 451);
            label31.Name = "label31";
            label31.Size = new Size(237, 20);
            label31.TabIndex = 44;
            label31.Text = "Дата предполагаемого возврата";
            // 
            // textBox17
            // 
            textBox17.Location = new Point(476, 474);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(236, 27);
            textBox17.TabIndex = 43;
            // 
            // textBox30
            // 
            textBox30.Location = new Point(736, 474);
            textBox30.Name = "textBox30";
            textBox30.Size = new Size(236, 27);
            textBox30.TabIndex = 42;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(878, 384);
            label32.Name = "label32";
            label32.Size = new Size(127, 20);
            label32.TabIndex = 41;
            label32.Text = "ID Библиотекаря";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(620, 384);
            label33.Name = "label33";
            label33.Size = new Size(70, 20);
            label33.TabIndex = 40;
            label33.Text = "ID Книги";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(360, 384);
            label34.Name = "label34";
            label34.Size = new Size(91, 20);
            label34.TabIndex = 39;
            label34.Text = "ID Читателя";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(101, 384);
            label35.Name = "label35";
            label35.Size = new Size(81, 20);
            label35.TabIndex = 38;
            label35.Text = "ID Выдачи";
            // 
            // textBox31
            // 
            textBox31.Location = new Point(877, 406);
            textBox31.Name = "textBox31";
            textBox31.Size = new Size(235, 27);
            textBox31.TabIndex = 37;
            // 
            // textBox32
            // 
            textBox32.Location = new Point(619, 406);
            textBox32.Name = "textBox32";
            textBox32.Size = new Size(235, 27);
            textBox32.TabIndex = 36;
            // 
            // textBox33
            // 
            textBox33.Location = new Point(359, 406);
            textBox33.Name = "textBox33";
            textBox33.Size = new Size(235, 27);
            textBox33.TabIndex = 35;
            // 
            // textBox34
            // 
            textBox34.Location = new Point(100, 406);
            textBox34.Name = "textBox34";
            textBox34.Size = new Size(235, 27);
            textBox34.TabIndex = 34;
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(3, 3);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowHeadersWidth = 51;
            dataGridView4.Size = new Size(1165, 357);
            dataGridView4.TabIndex = 3;
            // 
            // Журнал_событий
            // 
            Журнал_событий.Controls.Add(button13);
            Журнал_событий.Controls.Add(dataGridView5);
            Журнал_событий.Location = new Point(4, 29);
            Журнал_событий.Name = "Журнал_событий";
            Журнал_событий.Size = new Size(1170, 652);
            Журнал_событий.TabIndex = 4;
            Журнал_событий.Text = "Журнал событий";
            Журнал_событий.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(506, 448);
            button13.Name = "button13";
            button13.Size = new Size(137, 31);
            button13.TabIndex = 23;
            button13.Text = "Удалить";
            button13.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(3, 3);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.RowHeadersWidth = 51;
            dataGridView5.Size = new Size(1165, 357);
            dataGridView5.TabIndex = 4;
            // 
            // Администратор
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 604);
            Controls.Add(tabControl1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Администратор";
            Text = "Администратор";
            Load += Администратор_Load;
            tabControl1.ResumeLayout(false);
            Читатели.ResumeLayout(false);
            Читатели.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            Книги.ResumeLayout(false);
            Книги.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            Библиотекарь.ResumeLayout(false);
            Библиотекарь.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            Выдача_книг.ResumeLayout(false);
            Выдача_книг.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            Журнал_событий.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage Читатели;
        private TabPage Книги;
        private TabPage Библиотекарь;
        private TextBox textBox1;
        private DataGridView dataGridView1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox7;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox2;
        private Label label7;
        private Button button1;
        private Button button3;
        private Button button2;
        private DataGridView dataGridView2;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox11;
        private Label label10;
        private Label label8;
        private Label label12;
        private DataGridView dataGridView3;
        private TextBox textBox24;
        private TextBox textBox22;
        private TextBox textBox21;
        private TextBox textBox20;
        private TextBox textBox19;
        private TextBox textBox18;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private TabPage Журнал_событий;
        private Label label20;
        private Label label19;
        private TextBox textBox25;
        private TextBox textBox23;
        private Label label22;
        private TextBox textBox27;
        private Label label21;
        private TextBox textBox26;
        private Label label26;
        private TextBox textBox29;
        private Label label25;
        private TextBox textBox28;
        private Label label24;
        private TextBox textBox9;
        private Label label23;
        private TextBox textBox8;
        private Label label9;
        private Label label28;
        private Label label29;
        private TextBox textBox15;
        private TextBox textBox16;
        private Label label11;
        private TextBox textBox10;
        private Label label27;
        private TextBox textBox12;
        private TabPage Выдача_книг;
        private Label label36;
        private TextBox textBox35;
        private Label label30;
        private Label label31;
        private TextBox textBox17;
        private TextBox textBox30;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label35;
        private TextBox textBox31;
        private TextBox textBox32;
        private TextBox textBox33;
        private TextBox textBox34;
        private DataGridView dataGridView4;
        private Button button4;
        private Button button5;
        private Button button9;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private DataGridView dataGridView5;
    }
}