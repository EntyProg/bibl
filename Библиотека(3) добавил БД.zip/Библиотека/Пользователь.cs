﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Библиотека
{
    public partial class Пользователь : Form
    {

        private SQLiteConnection connection;

        public Пользователь()
        {
            InitializeComponent();
            ConnectToDatabase();
        }

        private void ConnectToDatabase()
        {
            string dbPath = "E:\\LibSQL.db";
            connection = new SQLiteConnection($"Data Source={dbPath}");
            connection.Open();
        }

        private void Пользователь_Load(object sender, EventArgs e)
        {
            string dbPath = "E:\\LibSQL.db";
            string connectionString = $"Data Source={dbPath}";

            //Книги
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM Books";

                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(command))
                    {
                        DataTable BooksTable = new DataTable();
                        adapter.Fill(BooksTable);
                        dataGridView5.DataSource = BooksTable;
                    }
                }
            }

            //Журнал событий
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string query = "SELECT * FROM EventsLog";

                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(command))
                    {
                        DataTable EventsLogTable = new DataTable();
                        adapter.Fill(EventsLogTable);
                        dataGridView5.DataSource = EventsLogTable;
                    }
                }
            }
        }

        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
