﻿namespace Библиотека
{
    partial class Пользователь
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Пользователь));
            tabControl1 = new TabControl();
            Поиск_книги = new TabPage();
            button9 = new Button();
            label24 = new Label();
            textBox9 = new TextBox();
            label23 = new Label();
            textBox8 = new TextBox();
            label9 = new Label();
            label12 = new Label();
            label10 = new Label();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox11 = new TextBox();
            dataGridView5 = new DataGridView();
            Заявка_на_книгу = new TabPage();
            button1 = new Button();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            textBox2 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            dataGridView1 = new DataGridView();
            Мои_книги = new TabPage();
            dataGridView2 = new DataGridView();
            История_выдачи_книг = new TabPage();
            dataGridView3 = new DataGridView();
            tabControl1.SuspendLayout();
            Поиск_книги.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            Заявка_на_книгу.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            Мои_книги.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            История_выдачи_книг.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Поиск_книги);
            tabControl1.Controls.Add(Заявка_на_книгу);
            tabControl1.Controls.Add(Мои_книги);
            tabControl1.Controls.Add(История_выдачи_книг);
            tabControl1.Location = new Point(1, 2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1183, 686);
            tabControl1.TabIndex = 0;
            // 
            // Поиск_книги
            // 
            Поиск_книги.Controls.Add(button9);
            Поиск_книги.Controls.Add(label24);
            Поиск_книги.Controls.Add(textBox9);
            Поиск_книги.Controls.Add(label23);
            Поиск_книги.Controls.Add(textBox8);
            Поиск_книги.Controls.Add(label9);
            Поиск_книги.Controls.Add(label12);
            Поиск_книги.Controls.Add(label10);
            Поиск_книги.Controls.Add(textBox13);
            Поиск_книги.Controls.Add(textBox14);
            Поиск_книги.Controls.Add(textBox11);
            Поиск_книги.Controls.Add(dataGridView5);
            Поиск_книги.Location = new Point(4, 29);
            Поиск_книги.Name = "Поиск_книги";
            Поиск_книги.Size = new Size(1175, 653);
            Поиск_книги.TabIndex = 1;
            Поиск_книги.Text = "Поиск книги";
            Поиск_книги.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(534, 570);
            button9.Name = "button9";
            button9.Size = new Size(137, 31);
            button9.TabIndex = 48;
            button9.Text = "Поиск";
            button9.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(628, 483);
            label24.Name = "label24";
            label24.Size = new Size(95, 20);
            label24.TabIndex = 54;
            label24.Text = "Год издания";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(628, 505);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(263, 27);
            textBox9.TabIndex = 53;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(359, 483);
            label23.Name = "label23";
            label23.Size = new Size(48, 20);
            label23.TabIndex = 52;
            label23.Text = "Жанр";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(359, 505);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(263, 27);
            textBox8.TabIndex = 51;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(735, 418);
            label9.Name = "label9";
            label9.Size = new Size(77, 20);
            label9.TabIndex = 50;
            label9.Text = "Название";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(197, 418);
            label12.Name = "label12";
            label12.Size = new Size(70, 20);
            label12.TabIndex = 49;
            label12.Text = "ID Книги";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(466, 419);
            label10.Name = "label10";
            label10.Size = new Size(51, 20);
            label10.TabIndex = 47;
            label10.Text = "Автор";
            // 
            // textBox13
            // 
            textBox13.Location = new Point(735, 441);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(263, 27);
            textBox13.TabIndex = 46;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(197, 441);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(263, 27);
            textBox14.TabIndex = 45;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(466, 441);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(263, 27);
            textBox11.TabIndex = 44;
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(3, 3);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.RowHeadersWidth = 51;
            dataGridView5.Size = new Size(1165, 357);
            dataGridView5.TabIndex = 43;
            dataGridView5.CellContentClick += dataGridView5_CellContentClick;
            // 
            // Заявка_на_книгу
            // 
            Заявка_на_книгу.Controls.Add(button1);
            Заявка_на_книгу.Controls.Add(label1);
            Заявка_на_книгу.Controls.Add(textBox1);
            Заявка_на_книгу.Controls.Add(label2);
            Заявка_на_книгу.Controls.Add(textBox2);
            Заявка_на_книгу.Controls.Add(label3);
            Заявка_на_книгу.Controls.Add(label4);
            Заявка_на_книгу.Controls.Add(label5);
            Заявка_на_книгу.Controls.Add(textBox3);
            Заявка_на_книгу.Controls.Add(textBox4);
            Заявка_на_книгу.Controls.Add(textBox5);
            Заявка_на_книгу.Controls.Add(dataGridView1);
            Заявка_на_книгу.Location = new Point(4, 29);
            Заявка_на_книгу.Name = "Заявка_на_книгу";
            Заявка_на_книгу.Size = new Size(1175, 653);
            Заявка_на_книгу.TabIndex = 4;
            Заявка_на_книгу.Text = "Заявка на книгу";
            Заявка_на_книгу.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(533, 553);
            button1.Name = "button1";
            button1.Size = new Size(137, 31);
            button1.TabIndex = 59;
            button1.Text = "Подать заявку";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(602, 479);
            label1.Name = "label1";
            label1.Size = new Size(95, 20);
            label1.TabIndex = 65;
            label1.Text = "Год издания";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(602, 501);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(263, 27);
            textBox1.TabIndex = 64;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(333, 479);
            label2.Name = "label2";
            label2.Size = new Size(48, 20);
            label2.TabIndex = 63;
            label2.Text = "Жанр";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(333, 501);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(263, 27);
            textBox2.TabIndex = 62;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(748, 415);
            label3.Name = "label3";
            label3.Size = new Size(77, 20);
            label3.TabIndex = 61;
            label3.Text = "Название";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(210, 415);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 60;
            label4.Text = "ID Книги";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(479, 416);
            label5.Name = "label5";
            label5.Size = new Size(51, 20);
            label5.TabIndex = 58;
            label5.Text = "Автор";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(748, 438);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(263, 27);
            textBox3.TabIndex = 57;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(210, 438);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(263, 27);
            textBox4.TabIndex = 56;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(479, 438);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(263, 27);
            textBox5.TabIndex = 55;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(3, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1165, 357);
            dataGridView1.TabIndex = 44;
            // 
            // Мои_книги
            // 
            Мои_книги.Controls.Add(dataGridView2);
            Мои_книги.Location = new Point(4, 29);
            Мои_книги.Name = "Мои_книги";
            Мои_книги.Size = new Size(1175, 653);
            Мои_книги.TabIndex = 2;
            Мои_книги.Text = "Мои книги";
            Мои_книги.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(3, 3);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(1165, 643);
            dataGridView2.TabIndex = 45;
            // 
            // История_выдачи_книг
            // 
            История_выдачи_книг.Controls.Add(dataGridView3);
            История_выдачи_книг.Location = new Point(4, 29);
            История_выдачи_книг.Name = "История_выдачи_книг";
            История_выдачи_книг.Size = new Size(1175, 653);
            История_выдачи_книг.TabIndex = 3;
            История_выдачи_книг.Text = "История выдачи книг";
            История_выдачи_книг.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(5, 5);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(1165, 643);
            dataGridView3.TabIndex = 46;
            // 
            // Пользователь
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1184, 689);
            Controls.Add(tabControl1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Пользователь";
            Text = "Пользователь";
            Load += Пользователь_Load;
            tabControl1.ResumeLayout(false);
            Поиск_книги.ResumeLayout(false);
            Поиск_книги.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            Заявка_на_книгу.ResumeLayout(false);
            Заявка_на_книгу.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            Мои_книги.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            История_выдачи_книг.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage Поиск_книги;
        private TabPage Мои_книги;
        private TabPage Заявка_на_книгу;
        private TabPage История_выдачи_книг;
        private DataGridView dataGridView5;
        private Button button9;
        private Label label24;
        private TextBox textBox9;
        private Label label23;
        private TextBox textBox8;
        private Label label9;
        private Label label12;
        private Label label10;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox11;
        private DataGridView dataGridView1;
        private Button button1;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private TextBox textBox2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private DataGridView dataGridView2;
        private DataGridView dataGridView3;
    }
}