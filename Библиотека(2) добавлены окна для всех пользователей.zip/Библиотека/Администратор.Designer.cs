﻿namespace Библиотека
{
    partial class Администратор
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            Читатели = new TabPage();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox7 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            dataGridView1 = new DataGridView();
            Книги = new TabPage();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            button5 = new Button();
            button4 = new Button();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            textBox14 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            dataGridView2 = new DataGridView();
            Библиотекарь = new TabPage();
            button8 = new Button();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            button7 = new Button();
            button6 = new Button();
            textBox24 = new TextBox();
            textBox22 = new TextBox();
            textBox21 = new TextBox();
            textBox20 = new TextBox();
            textBox19 = new TextBox();
            textBox18 = new TextBox();
            dataGridView3 = new DataGridView();
            tabControl1.SuspendLayout();
            Читатели.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            Книги.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            Библиотекарь.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Читатели);
            tabControl1.Controls.Add(Книги);
            tabControl1.Controls.Add(Библиотекарь);
            tabControl1.Location = new Point(3, 1);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1178, 685);
            tabControl1.TabIndex = 0;
            // 
            // Читатели
            // 
            Читатели.Controls.Add(button3);
            Читатели.Controls.Add(button2);
            Читатели.Controls.Add(button1);
            Читатели.Controls.Add(label7);
            Читатели.Controls.Add(label6);
            Читатели.Controls.Add(label5);
            Читатели.Controls.Add(label4);
            Читатели.Controls.Add(label3);
            Читатели.Controls.Add(label2);
            Читатели.Controls.Add(label1);
            Читатели.Controls.Add(textBox7);
            Читатели.Controls.Add(textBox5);
            Читатели.Controls.Add(textBox6);
            Читатели.Controls.Add(textBox3);
            Читатели.Controls.Add(textBox4);
            Читатели.Controls.Add(textBox2);
            Читатели.Controls.Add(textBox1);
            Читатели.Controls.Add(dataGridView1);
            Читатели.Location = new Point(4, 29);
            Читатели.Name = "Читатели";
            Читатели.Padding = new Padding(3);
            Читатели.Size = new Size(1170, 652);
            Читатели.TabIndex = 0;
            Читатели.Text = "Читатели";
            Читатели.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(670, 509);
            button3.Name = "button3";
            button3.Size = new Size(137, 31);
            button3.TabIndex = 17;
            button3.Text = "Удалить";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(513, 509);
            button2.Name = "button2";
            button2.Size = new Size(137, 31);
            button2.TabIndex = 16;
            button2.Text = "Изменить";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(356, 509);
            button1.Name = "button1";
            button1.Size = new Size(137, 31);
            button1.TabIndex = 15;
            button1.Text = "Добавить";
            button1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(984, 399);
            label7.Name = "label7";
            label7.Size = new Size(69, 20);
            label7.TabIndex = 14;
            label7.Text = "Телефон";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(827, 399);
            label6.Name = "label6";
            label6.Size = new Size(57, 20);
            label6.TabIndex = 13;
            label6.Text = "Номер";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(670, 399);
            label5.Name = "label5";
            label5.Size = new Size(52, 20);
            label5.TabIndex = 12;
            label5.Text = "Серия";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(513, 399);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 11;
            label4.Text = "Отчество";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(356, 399);
            label3.Name = "label3";
            label3.Size = new Size(39, 20);
            label3.TabIndex = 10;
            label3.Text = "Имя";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(199, 399);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 9;
            label2.Text = "Фамилия";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(42, 399);
            label1.Name = "label1";
            label1.Size = new Size(24, 20);
            label1.TabIndex = 8;
            label1.Text = "ID";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(984, 422);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(151, 27);
            textBox7.TabIndex = 7;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(827, 422);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(151, 27);
            textBox5.TabIndex = 6;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(670, 422);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(151, 27);
            textBox6.TabIndex = 5;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(513, 422);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(151, 27);
            textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(356, 422);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(151, 27);
            textBox4.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(199, 422);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(151, 27);
            textBox2.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(42, 422);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(151, 27);
            textBox1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(2, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1165, 357);
            dataGridView1.TabIndex = 0;
            // 
            // Книги
            // 
            Книги.Controls.Add(label12);
            Книги.Controls.Add(label11);
            Книги.Controls.Add(label10);
            Книги.Controls.Add(label9);
            Книги.Controls.Add(label8);
            Книги.Controls.Add(button5);
            Книги.Controls.Add(button4);
            Книги.Controls.Add(textBox15);
            Книги.Controls.Add(textBox16);
            Книги.Controls.Add(textBox17);
            Книги.Controls.Add(textBox12);
            Книги.Controls.Add(textBox13);
            Книги.Controls.Add(textBox14);
            Книги.Controls.Add(textBox10);
            Книги.Controls.Add(textBox11);
            Книги.Controls.Add(textBox9);
            Книги.Controls.Add(textBox8);
            Книги.Controls.Add(dataGridView2);
            Книги.Location = new Point(4, 29);
            Книги.Name = "Книги";
            Книги.Padding = new Padding(3);
            Книги.Size = new Size(1170, 652);
            Книги.TabIndex = 1;
            Книги.Text = "Книги";
            Книги.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(220, 442);
            label12.Name = "label12";
            label12.Size = new Size(70, 20);
            label12.TabIndex = 18;
            label12.Text = "ID Книги";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(690, 375);
            label11.Name = "label11";
            label11.Size = new Size(122, 20);
            label11.TabIndex = 17;
            label11.Text = "Номер читателя";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(448, 375);
            label10.Name = "label10";
            label10.Size = new Size(97, 20);
            label10.TabIndex = 16;
            label10.Text = "Дата выдачи";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(220, 375);
            label9.Name = "label9";
            label9.Size = new Size(127, 20);
            label9.TabIndex = 15;
            label9.Text = "ID Библиотекаря";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 375);
            label8.Name = "label8";
            label8.Size = new Size(91, 20);
            label8.TabIndex = 14;
            label8.Text = "ID Читателя";
            // 
            // button5
            // 
            button5.Location = new Point(1017, 465);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 13;
            button5.Text = "button5";
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(854, 464);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 12;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(690, 535);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(125, 27);
            textBox15.TabIndex = 11;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(448, 535);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(125, 27);
            textBox16.TabIndex = 10;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(220, 535);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(125, 27);
            textBox17.TabIndex = 9;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(690, 465);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(125, 27);
            textBox12.TabIndex = 8;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(448, 465);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(125, 27);
            textBox13.TabIndex = 7;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(220, 465);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(125, 27);
            textBox14.TabIndex = 6;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(690, 397);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(125, 27);
            textBox10.TabIndex = 5;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(448, 397);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(125, 27);
            textBox11.TabIndex = 4;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(220, 397);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(125, 27);
            textBox9.TabIndex = 3;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(6, 397);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(125, 27);
            textBox8.TabIndex = 2;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(2, 3);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(1165, 357);
            dataGridView2.TabIndex = 1;
            // 
            // Библиотекарь
            // 
            Библиотекарь.Controls.Add(button8);
            Библиотекарь.Controls.Add(label18);
            Библиотекарь.Controls.Add(label17);
            Библиотекарь.Controls.Add(label16);
            Библиотекарь.Controls.Add(label15);
            Библиотекарь.Controls.Add(label14);
            Библиотекарь.Controls.Add(label13);
            Библиотекарь.Controls.Add(button7);
            Библиотекарь.Controls.Add(button6);
            Библиотекарь.Controls.Add(textBox24);
            Библиотекарь.Controls.Add(textBox22);
            Библиотекарь.Controls.Add(textBox21);
            Библиотекарь.Controls.Add(textBox20);
            Библиотекарь.Controls.Add(textBox19);
            Библиотекарь.Controls.Add(textBox18);
            Библиотекарь.Controls.Add(dataGridView3);
            Библиотекарь.Location = new Point(4, 29);
            Библиотекарь.Name = "Библиотекарь";
            Библиотекарь.Size = new Size(1170, 652);
            Библиотекарь.TabIndex = 2;
            Библиотекарь.Text = "Библиотекарь";
            Библиотекарь.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(713, 498);
            button8.Name = "button8";
            button8.Size = new Size(118, 29);
            button8.TabIndex = 21;
            button8.Text = "Удалить";
            button8.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(958, 396);
            label18.Name = "label18";
            label18.Size = new Size(52, 20);
            label18.TabIndex = 20;
            label18.Text = "E-mail";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(793, 396);
            label17.Name = "label17";
            label17.Size = new Size(57, 20);
            label17.TabIndex = 19;
            label17.Text = "Номер";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(633, 396);
            label16.Name = "label16";
            label16.Size = new Size(72, 20);
            label16.TabIndex = 18;
            label16.Text = "Отчество";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(468, 396);
            label15.Name = "label15";
            label15.Size = new Size(39, 20);
            label15.TabIndex = 17;
            label15.Text = "Имя";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(295, 396);
            label14.Name = "label14";
            label14.Size = new Size(73, 20);
            label14.TabIndex = 16;
            label14.Text = "Фамилия";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(113, 396);
            label13.Name = "label13";
            label13.Size = new Size(127, 20);
            label13.TabIndex = 15;
            label13.Text = "ID Библиотекаря";
            // 
            // button7
            // 
            button7.Location = new Point(559, 498);
            button7.Name = "button7";
            button7.Size = new Size(118, 29);
            button7.TabIndex = 11;
            button7.Text = "Изменить";
            button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(404, 498);
            button6.Name = "button6";
            button6.Size = new Size(118, 29);
            button6.TabIndex = 10;
            button6.Text = "Добавить";
            button6.UseVisualStyleBackColor = true;
            // 
            // textBox24
            // 
            textBox24.Location = new Point(958, 419);
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(125, 27);
            textBox24.TabIndex = 8;
            // 
            // textBox22
            // 
            textBox22.Location = new Point(793, 419);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(125, 27);
            textBox22.TabIndex = 7;
            // 
            // textBox21
            // 
            textBox21.Location = new Point(633, 419);
            textBox21.Name = "textBox21";
            textBox21.Size = new Size(125, 27);
            textBox21.TabIndex = 6;
            // 
            // textBox20
            // 
            textBox20.Location = new Point(468, 419);
            textBox20.Name = "textBox20";
            textBox20.Size = new Size(125, 27);
            textBox20.TabIndex = 5;
            // 
            // textBox19
            // 
            textBox19.Location = new Point(295, 419);
            textBox19.Name = "textBox19";
            textBox19.Size = new Size(125, 27);
            textBox19.TabIndex = 4;
            // 
            // textBox18
            // 
            textBox18.Location = new Point(113, 419);
            textBox18.Name = "textBox18";
            textBox18.Size = new Size(125, 27);
            textBox18.TabIndex = 3;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(2, 3);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(1165, 357);
            dataGridView3.TabIndex = 2;
            // 
            // Администратор
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 604);
            Controls.Add(tabControl1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Администратор";
            Text = "Администратор";
            Load += Администратор_Load;
            tabControl1.ResumeLayout(false);
            Читатели.ResumeLayout(false);
            Читатели.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            Книги.ResumeLayout(false);
            Книги.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            Библиотекарь.ResumeLayout(false);
            Библиотекарь.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage Читатели;
        private TabPage Книги;
        private TabPage Библиотекарь;
        private TextBox textBox1;
        private DataGridView dataGridView1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox7;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox2;
        private Label label7;
        private Button button1;
        private Button button3;
        private Button button2;
        private DataGridView dataGridView2;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox9;
        private TextBox textBox8;
        private Button button5;
        private Button button4;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label12;
        private DataGridView dataGridView3;
        private Button button7;
        private Button button6;
        private TextBox textBox24;
        private TextBox textBox22;
        private TextBox textBox21;
        private TextBox textBox20;
        private TextBox textBox19;
        private TextBox textBox18;
        private Button button8;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
    }
}