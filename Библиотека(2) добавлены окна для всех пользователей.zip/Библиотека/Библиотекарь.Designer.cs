﻿namespace Библиотека
{
    partial class Библиотекарь
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            Читатели = new TabPage();
            Книги = new TabPage();
            Запросы = new TabPage();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Читатели);
            tabControl1.Controls.Add(Книги);
            tabControl1.Controls.Add(Запросы);
            tabControl1.Location = new Point(3, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1177, 531);
            tabControl1.TabIndex = 0;
            // 
            // Читатели
            // 
            Читатели.Location = new Point(4, 29);
            Читатели.Name = "Читатели";
            Читатели.Padding = new Padding(3);
            Читатели.Size = new Size(1169, 498);
            Читатели.TabIndex = 0;
            Читатели.Text = "Читатели";
            Читатели.UseVisualStyleBackColor = true;
            // 
            // Книги
            // 
            Книги.Location = new Point(4, 29);
            Книги.Name = "Книги";
            Книги.Padding = new Padding(3);
            Книги.Size = new Size(1169, 498);
            Книги.TabIndex = 1;
            Книги.Text = "Книги";
            Книги.UseVisualStyleBackColor = true;
            // 
            // Запросы
            // 
            Запросы.Location = new Point(4, 29);
            Запросы.Name = "Запросы";
            Запросы.Size = new Size(1169, 498);
            Запросы.TabIndex = 2;
            Запросы.Text = "Запросы";
            Запросы.UseVisualStyleBackColor = true;
            // 
            // Библиотекарь
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1181, 536);
            Controls.Add(tabControl1);
            Name = "Библиотекарь";
            Text = "Библиотекарь";
            Load += Библиотекарь_Load;
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage Читатели;
        private TabPage Книги;
        private TabPage Запросы;
    }
}