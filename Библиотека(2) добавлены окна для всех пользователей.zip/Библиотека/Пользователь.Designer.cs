﻿namespace Библиотека
{
    partial class Пользователь
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            Выбрать_книгу = new TabPage();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Выбрать_книгу);
            tabControl1.Location = new Point(1, 2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(942, 553);
            tabControl1.TabIndex = 0;
            // 
            // Выбрать_книгу
            // 
            Выбрать_книгу.Location = new Point(4, 29);
            Выбрать_книгу.Name = "Выбрать_книгу";
            Выбрать_книгу.Padding = new Padding(3);
            Выбрать_книгу.Size = new Size(934, 520);
            Выбрать_книгу.TabIndex = 0;
            Выбрать_книгу.Text = "Выбрать книгу";
            Выбрать_книгу.UseVisualStyleBackColor = true;
            // 
            // Пользователь
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(946, 557);
            Controls.Add(tabControl1);
            Name = "Пользователь";
            Text = "Пользователь";
            Load += Пользователь_Load;
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage Выбрать_книгу;
    }
}